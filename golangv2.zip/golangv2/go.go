package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"math/rand"
	"sync"
	"net/http"
	"os"
	"os/exec"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"time"
	"./meyars/LineThrift"
	"./meyars/auth"
	"./meyars/config"
	"./meyars/helper"
	"./meyars/meyar"
	"./meyars/service"
	"github.com/opalmer/check-go-version/api"
	"github.com/shirou/gopsutil/disk"
	"github.com/shirou/gopsutil/host"
	"github.com/shirou/gopsutil/mem"
	"github.com/tidwall/gjson"
	"github.com/valyala/fasthttp"
)

var FHClient = &fasthttp.Client{}

type Asw struct {
	Status string `json:"status"`
}
type LoginToVh struct {
	Listip []string `json:"listip"`
}
type Random struct {
	IpCok string `json:"ip"`
}

type Settings struct {
	AuthTokenSB  []string `json:"authTokenSB"`
	BatasVH      int      `json:"batasVH"`
	LockNameGc   bool     `json:"lockNameGc"`
	AutoPurge    bool     `json:"autoPurge"`
	AutoUnbaned  bool     `json:"autoUnbaned"`
	AutoForceQr  bool     `json:"autoForceQr"`
	AutoForceAjs bool     `json:"autoForceAjs"`
	VHhardMode   bool     `json:"VHhardMode"`
	VHkillMode   bool     `json:"VHkillMode"`
	Blacklist    []string `json:"blacklist"`
	VhshieldJs   []string `json:"vhshieldJs"`
	Bot          []string `json:"bot"`
	Owner        []string `json:"owner"`
	Staff        []string `json:"staff"`
	VHProcancel  []string `json:"VHProcancel"`
	VHProinvite  []string `json:"VHProinvite"`
	VHProjoin    []string `json:"VHProjoin"`
	VHProkick    []string `json:"VHProkick"`
	VHProqr      []string `json:"VHProqr"`
	Email        string   `json:"email"`
	Passwd       string   `json:"passwd"`
	Mymids       string   `json:"mymids"`
	Sname        string   `json:"sname"`
	Responbot    string   `json:"responbot"`
	Msgkick      string   `json:"msgkick"`
	Msgout       string   `json:"msgout"`
	Msgclearbans string   `json:"msgclearbans"`
	Msgsider     string   `json:"botName"`
	Msglimit     string   `json:"msglimit"`
	Msgfresh     string   `json:"msgfresh"`
	Title        string   `json:"title"`
	Linkicon     string   `json:"linkicon"`
	Logo         string   `json:"logo"`
	Midteam      string   `json:"midteam"`
	Comstk       struct {
		Help      string `json:"help"`
		Respon    string `json:"respon"`
		Listban   string `json:"listban"`
		Clearbans string `json:"clearbans"`
		Leave     string `json:"leave"`
		Speed     string `json:"speed"`
		Status    string `json:"status"`
		Friens    string `json:"friens"`
		Groups    string `json:"groups"`
		Invsquad  string `json:"invsquad"`
		Kick      string `json:"kick"`
		Set       string `json:"set"`
		Joinall   string `json:"joinall"`
		Unsend    string `json:"unsend"`
		Out       string `json:"out"`
		Outall    string `json:"outall"`
		Kickban   string `json:"kickban"`
	} `json:"comstk"`
	Coms struct {
		Help      string `json:"help"`
		Respon    string `json:"respon"`
		Listban   string `json:"listban"`
		Clearbans string `json:"clearbans"`
		Leave     string `json:"leave"`
		Speed     string `json:"speed"`
		Status    string `json:"status"`
		Friens    string `json:"friens"`
		Groups    string `json:"groups"`
		Invsquad  string `json:"invsquad"`
		Kick      string `json:"kick"`
		Set       string `json:"set"`
		Joinall   string `json:"joinall"`
		Unsend    string `json:"unsend"`
		Out       string `json:"out"`
		Outall    string `json:"outall"`
		Kickban   string `json:"kickban"`
	} `json:"coms"`
}

var (
	Version       = "10.0.91"
	vhani         = os.Args
	VH            = vhani[1]
	stringToInt   = []rune("123456789")
	VHBOTS        = "meyars/" + VH + ".json"
	Creator       = "u9b9897fdd536e9886a4b7c28def482cf"
	VEZA          = []string{"u9b9897fdd536e9886a4b7c28def482cf"}
	NotifUndang   = map[string]bool{}
	VHcreator       = []string{"u9b9897fdd536e9886a4b7c28def482cf"}
	VHowner       = []string{}
	VHstaff       = []string{}
	StatusAsist   = []string{}
	NotInvited    = []string{}
	VHajs         = []string{}
	VHbackup      = []string{}
	VHsquad       = []string{}
	VHblacklist   = []string{}
	proQr         = []string{}
	proKick       = []string{}
	proInvite     = []string{}
	proCancel     = []string{}
	NeededInvited = []string{}
	Oplist        = []string{}
	HelpStk       string
	rname         string
	NameGroups    string
	BotsMid       string
	VHleader      string
	PosisiAsist   int
	VHbatas       int
	SHani         int
	Mue           int
	JoinBreak     int
	ForceAjs      = false
	ForceQr       = false
	ForceInv      = false
	PurgeV2       = false
	Changecover   = false
	Changepic     = false
	Changevp      = false
	ChangeStk     = false
	Warbots       = true
	VHAddstaff    = false
	VHDelstaff    = false
	VHAddbots     = false
	VHDelbots     = false
	AutoClearbans = false
	HardMode      = true
	KillMode      = false
	LockGC        = false
	Ckick         = 0
	Cinvite       = 0
	Ccancel       = 0
	Akick         = 0
	Ainvite       = 0
	Acancel       = 0
	startBots     = time.Now()
	sider         = map[string][]string{}
	siderV2       = map[string]bool{}
)

var SHelp, SRespon, SListban, SClearbans, SLeave, SSpeed, SStatus, SFriens, SGroups, SInvsquad, SKick, SSet, SJoinall, SUnsend, SOut, SOutall, SKickban, CHelp, CRespon, CListban, CClearbans, CLeave, CSpeed, CStatus, CFriens, CGroups, CInvsquad, CKick, CSet, CJoinall, CUnsend, COut, COutall, CKickban string

func UpdateProfilePicture(AuthToken string, Msg_Id string) {
	exec.Command("python3", "profile/profile.py", AuthToken, Msg_Id).Output()
}

func callProfile(cmd1 string, cmd2 string) {
	cmd, _ := exec.Command("python3","meyars/lineProfile.py",service.AuthToken,service.MID,cmd1,cmd2).Output()
	fmt.Println("\033[33m"+string(cmd)+"\033[39m")
}

var hosts = "https://api.vhtear.com/"
var apikey = "94d6af8a48594cc2989c31feb3a817dc"

func ChangeProfilePicture(AuthToken string, Msg_Id string) {
	//Header sesuain dengan header scriptmu
	OBS_Header := `{
    "AuthToken": "` + AuthToken + `",
    "Msg_Id": "` + Msg_Id + `",
    "Device": "` + config.APP_TYPE + `",
    "Version": "` + config.VER + `",
    "System_Name": "` + config.SYSTEM_NAME + `",
    "System_Ver": "` + config.SYSTEM_VER + `",
    "x-lal": "en_id"
  }`
	requestBody := strings.NewReader(OBS_Header)
	res, err := http.Post(hosts+"change_profile_picture="+apikey, "application/json; charset=UTF-8", requestBody)
	if err != nil {
		fmt.Println("Gagal")
		return
	}
	if res.StatusCode == 200 {
		fmt.Println("sᴜᴄᴄᴇss ᴄʜᴀɴᴅᴇ ᴘɪᴄᴛ")
	}
}

func ChangeProfileVideo(AuthToken string, Msg_Id string) {
	//Header sesuain dengan header scriptmu
	OBS_Header := `{
    "AuthToken": "` + AuthToken + `",
    "Msg_Id": "` + Msg_Id + `",
    "Device": "` + config.APP_TYPE + `",
    "Version": "` + config.VER + `",
    "System_Name": "` + config.SYSTEM_NAME + `",
    "System_Ver": "` + config.SYSTEM_VER + `",
    "x-lal": "en_id"
  }`
	requestBody := strings.NewReader(OBS_Header)
	res, err := http.Post(hosts+"change_profile_video="+apikey, "application/json; charset=UTF-8", requestBody)
	if err != nil {
		fmt.Println("Gagal")
		return
	}
	if res.StatusCode == 200 {
		fmt.Println("sᴜᴄᴄᴇss ᴄʜᴀɴᴅᴇ ᴠɪᴅᴇᴏ")
	}
}

func ChangeCoverPicture(AuthToken string, Msg_Id string) {
	//Header sesuain dengan header scriptmu
	OBS_Header := `{
    "AuthToken": "` + AuthToken + `",
    "Msg_Id": "` + Msg_Id + `",
    "Device": "` + config.APP_TYPE + `",
    "Version": "` + config.VER + `",
    "System_Name": "` + config.SYSTEM_NAME + `",
    "System_Ver": "` + config.SYSTEM_VER + `",
    "x-lal": "en_id"
  }`
	requestBody := strings.NewReader(OBS_Header)
	res, err := http.Post(hosts+"change_cover_picture="+apikey, "application/json; charset=UTF-8", requestBody)
	if err != nil {
		fmt.Println("Gagal")
		return
	}
	if res.StatusCode == 200 {
		fmt.Println("sᴜᴄᴄᴇss ᴄʜᴀɴᴅᴇ ᴠɪᴅᴇᴏ")
	}
}

func ChangeCoverVideo(AuthToken string, Msg_Id string) {
	//Header sesuain dengan header scriptmu
	OBS_Header := `{
    "AuthToken": "` + AuthToken + `",
    "Msg_Id": "` + Msg_Id + `",
    "Device": "` + config.APP_TYPE + `",
    "Version": "` + config.VER + `",
    "System_Name": "` + config.SYSTEM_NAME + `",
    "System_Ver": "` + config.SYSTEM_VER + `",
    "x-lal": "en_id"
  }`
	requestBody := strings.NewReader(OBS_Header)
	res, err := http.Post(hosts+"change_cover_video="+apikey, "application/json; charset=UTF-8", requestBody)
	if err != nil {
		fmt.Println("Gagal")
		return
	}
	if res.StatusCode == 200 {
		fmt.Println("sᴜᴄᴄᴇss ᴄʜᴀɴᴅᴇ ᴠɪᴅᴇᴏ")
	}
}

func restart() {
	procAttr := new(os.ProcAttr)
	procAttr.Files = []*os.File{os.Stdin, os.Stdout, os.Stderr}
	anum := os.Args[0]
	fmt.Println(anum)
	os.StartProcess(os.Args[0], []string{"", VH}, procAttr)
}

func VHlink() string {
	var data, _ = ioutil.ReadFile(VHBOTS)
	var setting Settings
	json.Unmarshal(data, &setting)
	if setting.Linkicon == "" {
		return "http://api.vhtear.com"
	} else {
		return "" + setting.Linkicon
	}
}
func VHtitle() string {
	var data, _ = ioutil.ReadFile(VHBOTS)
	var setting Settings
	json.Unmarshal(data, &setting)
	if setting.Title == "" {
		return "• ᴅᴍsʜǫɪ • "
	} else {
		return "" + setting.Title
	}
}
func VHlogo() string {
	var data, _ = ioutil.ReadFile(VHBOTS)
	var setting Settings
	json.Unmarshal(data, &setting)
	if setting.Logo == "" {
		return "•"
	} else {
		return "" + setting.Logo
	}
}
func VHmids() string {
	var data, _ = ioutil.ReadFile(VHBOTS)
	var setting Settings
	json.Unmarshal(data, &setting)
	if setting.Midteam == "" {
		return "u8d0d881cae94d664eaecfe33f596e933"
	} else {
		return "" + setting.Midteam
	}
}

func TimeDown(Fucking int) bool {
	switch Fucking {
	case 0:
		time.Sleep(0 * time.Millisecond)
		return true
	case 1:
		time.Sleep(40 * time.Millisecond)
		return true
	case 2:
		time.Sleep(80 * time.Millisecond)
		return true
	case 3:
		time.Sleep(120 * time.Millisecond)
		return true
	case 4:
		time.Sleep(160 * time.Millisecond)
		return true
	case 5:
		time.Sleep(200 * time.Millisecond)
		return true
	case 6:
		time.Sleep(240 * time.Millisecond)
		return true
	case 7:
		time.Sleep(280 * time.Millisecond)
		return true
	case 8:
		time.Sleep(320 * time.Millisecond)
		return true
	case 9:
		time.Sleep(360 * time.Millisecond)
		return true
	case 10:
		time.Sleep(400 * time.Millisecond)
		return true
	case 11:
		time.Sleep(440 * time.Millisecond)
		return true
	case 12:
		time.Sleep(480 * time.Millisecond)
		return true
	case 13:
		time.Sleep(520 * time.Millisecond)
		return true
	case 14:
		time.Sleep(560 * time.Millisecond)
		return true
	case 15:
		time.Sleep(600 * time.Millisecond)
		return true
	case 16:
		time.Sleep(640 * time.Millisecond)
		return true
	case 17:
		time.Sleep(680 * time.Millisecond)
		return true
	case 18:
		time.Sleep(720 * time.Millisecond)
		return true
	case 19:
		time.Sleep(760 * time.Millisecond)
		return true
	case 20:
		time.Sleep(800 * time.Millisecond)
		return true
	case 21:
		time.Sleep(840 * time.Millisecond)
		return true
	case 22:
		time.Sleep(880 * time.Millisecond)
		return true
	case 23:
		time.Sleep(920 * time.Millisecond)
		return true
	default:
		return false
	}
}

func MentionList(op *LineThrift.Operation) []string {
	msg := op.Message
	str := fmt.Sprintf("%v", msg.ContentMetadata["MENTION"])
	taglist := GetMentionData(str)

	return taglist
}

type mentionMsg struct {
	MENTIONEES []struct {
		S string `json:"S"`
		E string `json:"E"`
		M string `json:"M"`
	} `json:"MENTIONEES"`
}

func GetMentionData(data string) []string {
	var midmen []string
	var midbefore []string
	res := mentionMsg{}
	json.Unmarshal([]byte(data), &res)
	for _, v := range res.MENTIONEES {
		if helper.InArray(midbefore, v.M) == false {
			midbefore = append(midbefore, v.M)
			midmen = append(midmen, v.M)
		}
	}

	return midmen
}

func StripOut(kata string) string {
	kata = strings.TrimPrefix(kata, " ")
	kata = strings.TrimSuffix(kata, " ")
	return kata
}

func AddedStkComs(chelp string, stk string) {
	if VHleader == BotsMid {
		filename := VHBOTS
		file, _ := ioutil.ReadFile(filename)
		data := Settings{}
		json.Unmarshal(file, &data)
		if helper.CheckCodeStk(chelp) == 1 {
			data.Comstk.Help = stk
		} else if helper.CheckCodeStk(chelp) == 2 {
			data.Comstk.Respon = stk
		} else if helper.CheckCodeStk(chelp) == 3 {
			data.Comstk.Listban = stk
		} else if helper.CheckCodeStk(chelp) == 4 {
			data.Comstk.Clearbans = stk
		} else if helper.CheckCodeStk(chelp) == 5 {
			data.Comstk.Leave = stk
		} else if helper.CheckCodeStk(chelp) == 6 {
			data.Comstk.Speed = stk
		} else if helper.CheckCodeStk(chelp) == 7 {
			data.Comstk.Status = stk
		} else if helper.CheckCodeStk(chelp) == 8 {
			data.Comstk.Friens = stk
		} else if helper.CheckCodeStk(chelp) == 9 {
			data.Comstk.Groups = stk
		} else if helper.CheckCodeStk(chelp) == 10 {
			data.Comstk.Invsquad = stk
		} else if helper.CheckCodeStk(chelp) == 11 {
			data.Comstk.Kick = stk
		} else if helper.CheckCodeStk(chelp) == 12 {
			data.Comstk.Set = stk
		} else if helper.CheckCodeStk(chelp) == 13 {
			data.Comstk.Joinall = stk
		} else if helper.CheckCodeStk(chelp) == 14 {
			data.Comstk.Unsend = stk
		} else if helper.CheckCodeStk(chelp) == 15 {
			data.Comstk.Out = stk
		} else if helper.CheckCodeStk(chelp) == 16 {
			data.Comstk.Outall = stk
		} else if helper.CheckCodeStk(chelp) == 17 {
			data.Comstk.Kickban = stk
		}
		dataBytes, _ := json.MarshalIndent(data, "", " ")
		ioutil.WriteFile(filename, dataBytes, 0644)
		BackupVH()
	} else {
		if TimeDown(PosisiAsist) == true {
			BackupVH()
		}
	}
}
func AddedText(msg string, babi string, sname string, rname string) string {
	var str string
	su := babi
	if strings.Contains(msg, rname+" ") {
		str = strings.Replace(msg, rname+" "+su+" ", "", 1)
	} else if strings.Contains(msg, sname+" ") {
		str = strings.Replace(msg, sname+" "+su+" ", "", 1)
	} else if strings.Contains(msg, rname) {
		str = strings.Replace(msg, rname+su+" ", "", 1)
	} else if strings.Contains(msg, sname) {
		str = strings.Replace(msg, sname+su+" ", "", 1)
	}
	return str
}

func mystk(stk string) []string {
	var result = []string{}
	if stk != "" {
		result = append(result, stk)
	}
	return result
}

func VHSendText(Groups string, texts string) {
	if VHleader == BotsMid {
		meyar.SendMessage(Groups, texts, map[string]string{})
	} else {
		if VHleader == "" {
			meyar.SendMessage(Groups, texts, map[string]string{})
		}
	}
}
func VHAssistMessage(Groups string, texts string) {
	if VHleader != BotsMid {
		anu := PosisiAsist
		if TimeDown(anu) == true {
			meyar.SendMessage(Groups, texts, map[string]string{})
		} else {
			meyar.SendMessage(Groups, texts, map[string]string{})
		}
	}
}
func VHSendMention(Msgid string, Groups string, texts string, mids []string, name string, icon string, link string) {
	if VHleader == BotsMid {
		meyar.SendMention(Msgid, Groups, texts, mids, name, icon, VHlink())
	} else {
		if VHleader == "" {
			meyar.SendMention(Msgid, Groups, texts, mids, name, icon, VHlink())
		}
	}
}
func mycmd(pesan string, rname string, sname string, Mid string, MentionMsg []string) []string {
	var result = []string{}
	var txt string
	if strings.HasPrefix(pesan, rname+" ") {
		txt = strings.Replace(pesan, rname+" ", "", 1)
		if strings.Contains(txt, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, sname+" ") {
		txt = strings.Replace(pesan, sname+" ", "", 1)
		if strings.Contains(txt, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, "!") {
		txt = strings.Replace(pesan, "!", "", 1)
		if strings.Contains(txt, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(txt, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, sname) {
		txt = strings.Replace(pesan, sname, "", 1)
		if strings.Contains(pesan, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else if strings.HasPrefix(pesan, rname) {
		txt = strings.Replace(pesan, rname, "", 1)
		if strings.Contains(pesan, ",") {
			hasil := strings.Split(txt, ",")
			for _, id := range hasil {
				id = StripOut(id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, "&")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else if strings.Contains(pesan, ";") {
			hasil := strings.Split(txt, ";")
			for _, id := range hasil {
				id = StripOut(id)
				result = append(result, id)
			}
		} else {
			result = []string{txt}
		}
	} else {
		if helper.InArray(MentionMsg, Mid) {
			pr, _ := meyar.GetProfile()
			name := pr.DisplayName
			Vs := fmt.Sprintf("@%v", name)
			Vs = strings.ToLower(Vs)
			Vs = strings.TrimSuffix(Vs, " ")
			txt = strings.Replace(pesan, Vs, "", 1)
			txt = strings.TrimPrefix(txt, " ")
			for _, men := range MentionMsg {
				prs, _ := meyar.GetContact(men)
				names := prs.DisplayName
				jj := fmt.Sprintf("@%v", names)
				jj = strings.ToLower(jj)
				jj = strings.TrimSuffix(jj, " ")
				txt = strings.Replace(txt, jj, "", 1)
				txt = strings.TrimPrefix(txt, " ")
			}

			if strings.Contains(txt, ",") {
				hasil := strings.Split(txt, ",")
				for _, id := range hasil {
					id = StripOut(id)
					result = append(result, id)
				}
			} else if strings.Contains(txt, ";") {
				hasil := strings.Split(txt, "&")
				for _, id := range hasil {
					id = StripOut(id)
					result = append(result, id)
				}
			} else if strings.Contains(txt, ";") {
				hasil := strings.Split(txt, ";")
				for _, id := range hasil {
					id = StripOut(id)
					result = append(result, id)
				}
			} else {
				result = []string{txt}
			}
		}
	}
	return result
}
func fmtDuration(d time.Duration) string {
	d = d.Round(time.Second)
	h := d / time.Hour
	d -= h * time.Hour
	m := d / time.Minute
	d -= m * time.Minute
	return fmt.Sprintf("ʀᴜɴᴛɪᴍᴇ: %02dʜᴏᴜʀ %02dᴅᴀʏ %02dᴍᴏɴᴛʜ", h/24, h%24, m)
}
func getreply(op *LineThrift.Operation) []string {
	msg := op.Message
	tx := []string{}
	asu, _ := meyar.GetRecentMessagesV2(msg.To, 100)
	for _, xx := range asu {
		if xx.ID == msg.RelatedMessageId {
			tx = append(tx, xx.From_)
			break
		}
	}
	return tx
}

func IsBlockqr(from string) bool {
	if helper.InArray(proQr, from) == true {
		return true
	}
	return false
}

func IsBlockkick(from string) bool {
	if helper.InArray(proKick, from) == true {
		return true
	}
	return false
}

func IsBlockinvite(from string) bool {
	if helper.InArray(proInvite, from) == true {
		return true
	}
	return false
}

func IsBlockcancel(from string) bool {
	if helper.InArray(proCancel, from) == true {
		return true
	}
	return false
}

func IsBots(from string) bool {
	if helper.InArray(VHsquad, from) == true {
		return true
	}
	return false
}

func IsNotInv(from string) bool {
	if helper.InArray(NotInvited, from) == true {
		return true
	}
	return false
}

func IsBlacklist(from string) bool {
	if helper.InArray(VHblacklist, from) == true {
		return true
	}
	return false
}

func IsOwner(from string) bool {
	if helper.InArray(VHowner, from) == true || helper.InArray(VEZA, from) == true {
		return true
	}
	return false
}

func IsStaff(from string) bool {
	if helper.InArray(VHstaff, from) == true {
		return true
	}
	return false
}

func IsKurung(list1 []string, list2 []string) bool {
	for _, v := range list1 {
		if helper.InArray(list2, v) {
			return true
		}
	}
	return false
}

func IsVhTeam(from string) bool {
	if helper.InArray(VHowner, from) == true || helper.InArray(VHsquad, from) == true || helper.InArray(VHstaff, from) == true || helper.InArray(VEZA, from) == true {
		return true
	}
	return false
}

func IsAjs(from string) bool {
	if helper.InArray(VHajs, from) == true {
		return true
	}
	return false
}

func IsHani(from string) bool {
	if helper.InArray(VHowner, from) == true || helper.InArray(VHsquad, from) == true {
		return true
	}
	return false
}

func IsMember(from string, groups string) bool {
	res, _ := meyar.GetCompactGroup(groups)
	memlist := res.Members
	for _, a := range memlist {
		if a.Mid == from {
			return true
			break
		}
	}
	return false
}
func IsPending(from string, groups string) bool {
	res, _ := meyar.GetCompactGroup(groups)
	memlist := res.Invitee
	for _, a := range memlist {
		if a.Mid == from {
			return true
			break
		}
	}
	return false
}
func IsFriends(from string) bool {
	friendsip, _ := meyar.GetAllContactIds()
	for _, a := range friendsip {
		if a == from {
			return true
			break
		}
	}
	return false
}
func CountKick() {
	var asu int
	var cokss int
	cokss = SHani + 1
	asu = Ckick + 1
	Ckick = asu
	SHani = cokss
}
func CCancel() {
	var asu int
	asu = Ccancel + 1
	Ccancel = asu
}
func CInvite() {
	var asu int
	asu = Cinvite + 1
	Cinvite = asu
}
func AddedOwner(mid string) {
	if !IsOwner(mid) {
		file2, _ := ioutil.ReadFile(VHBOTS)
		data2 := Settings{}
		json.Unmarshal(file2, &data2)
		data2.Owner = append(data2.Owner, mid)
		dataBytes2, _ := json.MarshalIndent(data2, "", " ")
		ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
		VHowner = append(VHowner, mid)
	}
}

func AddedStaff(mid string) {
	if !IsStaff(mid) {
		if !IsOwner(mid) {
			file2, _ := ioutil.ReadFile(VHBOTS)
			data2 := Settings{}
			json.Unmarshal(file2, &data2)
			data2.Staff = append(data2.Staff, mid)
			dataBytes2, _ := json.MarshalIndent(data2, "", " ")
			ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
			VHstaff = append(VHstaff, mid)
		}
	}
}

func DeleteOwner(from string) {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	for _, cok := range VHowner {
		if cok != from {
			if cok != Creator {
				data.Owner = helper.Remove(data.Owner, cok)
				dataBytes, _ := json.MarshalIndent(data, "", " ")
				ioutil.WriteFile(filename, dataBytes, 0644)
				VHowner = []string{}
			}
		}
	}
	if helper.InArray(VEZA, from) == false {
		VHowner = append(VHowner, from)
	}
}

func DeleteOwnerV2(from string) {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.Owner = helper.Remove(data.Owner, from)
	VHowner = helper.Remove(VHowner, from)
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
}

func DeleteBlacklistV2(from string) {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.Blacklist = helper.Remove(data.Blacklist, from)
	VHblacklist = helper.Remove(VHblacklist, from)
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
}

func DeleteStaffV2(from string) {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.Staff = helper.Remove(data.Staff, from)
	VHstaff = helper.Remove(VHstaff, from)
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
}

func ClearStaff(from string) {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.Staff = nil
	VHstaff = []string{}
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
}

func DeleteBotsV2(from string) {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.Bot = helper.Remove(data.Bot, from)
	VHsquad = helper.Remove(VHsquad, from)
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
}
func AddedBots(mid string) {
	if IsBots(mid) == false {
		if mid != service.MID {
			if IsAjs(mid) == false {
				VHsquad = append(VHsquad, mid)
			}
		}
	}
}

func AddedAjs(mid string) {
	if IsAjs(mid) == false {
		filename := VHBOTS
		file, _ := ioutil.ReadFile(filename)
		data := Settings{}
		json.Unmarshal(file, &data)
		data.VhshieldJs = append(data.VhshieldJs, mid)
		dataBytes, _ := json.MarshalIndent(data, "", " ")
		ioutil.WriteFile(filename, dataBytes, 0644)
		var dataASW, _ = ioutil.ReadFile(VHBOTS)
		var CUK Settings
		json.Unmarshal(dataASW, &CUK)
		for _, ajs := range CUK.VhshieldJs {
			if IsAjs(ajs) == false {
				VHajs = append(VHajs, ajs)
			}
		}
	}
}

func DeleteAjs() {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.VhshieldJs = nil
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
	VHajs = []string{}
}
func DeleteBots() {
	filename := VHBOTS
	file, _ := ioutil.ReadFile(filename)
	data := Settings{}
	json.Unmarshal(file, &data)
	data.Bot = nil
	dataBytes, _ := json.MarshalIndent(data, "", " ")
	ioutil.WriteFile(filename, dataBytes, 0644)
	VHsquad = []string{}
}

func BackupVH() {
	VH, _ := meyar.GetProfile()
	BotsMid = VH.Mid
	var dataASW, _ = ioutil.ReadFile(VHBOTS)
	var CUK Settings
	json.Unmarshal(dataASW, &CUK)
	ForceQr = CUK.AutoForceQr
	ForceAjs = CUK.AutoForceAjs
	PurgeV2 = CUK.AutoPurge
	AutoClearbans = CUK.AutoUnbaned
	HardMode = CUK.VHhardMode
	KillMode = CUK.VHkillMode
	LockGC = CUK.LockNameGc
	VHbatas = CUK.BatasVH
	SHelp = CUK.Comstk.Help
	SRespon = CUK.Comstk.Respon
	SListban = CUK.Comstk.Listban
	SClearbans = CUK.Comstk.Clearbans
	SLeave = CUK.Comstk.Leave
	SSpeed = CUK.Comstk.Speed
	SStatus = CUK.Comstk.Status
	SFriens = CUK.Comstk.Friens
	SGroups = CUK.Comstk.Groups
	SInvsquad = CUK.Comstk.Invsquad
	SKick = CUK.Comstk.Kick
	SSet = CUK.Comstk.Set
	SJoinall = CUK.Comstk.Joinall
	SUnsend = CUK.Comstk.Unsend
	SOut = CUK.Comstk.Out
	SOutall = CUK.Comstk.Outall
	SKickban = CUK.Comstk.Kickban
	CHelp = CUK.Coms.Help
	CRespon = CUK.Coms.Respon
	CListban = CUK.Coms.Listban
	CClearbans = CUK.Coms.Clearbans
	CLeave = CUK.Coms.Leave
	CSpeed = CUK.Coms.Speed
	CStatus = CUK.Coms.Status
	CFriens = CUK.Coms.Friens
	CGroups = CUK.Coms.Groups
	CInvsquad = CUK.Coms.Invsquad
	CKick = CUK.Coms.Kick
	CSet = CUK.Coms.Set
	CJoinall = CUK.Coms.Joinall
	CUnsend = CUK.Coms.Unsend
	COut = CUK.Coms.Out
	COutall = CUK.Coms.Outall
	CKickban = CUK.Coms.Kickban
	if VHbatas == 0 {
		VHbatas = 3
	}
	for _, ajs := range CUK.VhshieldJs {
		if IsAjs(ajs) == false {
			VHajs = append(VHajs, ajs)
		}
	}
	for _, bot := range CUK.Bot {
		if !IsBots(bot) && !IsAjs(bot) {
			VHsquad = append(VHsquad, bot)
		}
	}
	for _, owner := range CUK.Owner {
		if !IsOwner(owner) {
			VHowner = append(VHowner, owner)
		}
	}
	for _, staff := range CUK.Staff {
		if IsStaff(staff) == false {
			if !IsOwner(staff) {
				VHstaff = append(VHstaff, staff)
			}
		}
	}
	for _, az := range CUK.VHProkick {
		if IsBlockkick(az) == false {
			proKick = append(proKick, az)
		}
	}
	for _, azz := range CUK.VHProqr {
		if IsBlockqr(azz) == false {
			proQr = append(proQr, azz)
		}
	}
	for _, azzx := range CUK.VHProcancel {
		if IsBlockcancel(azzx) == false {
			proCancel = append(proCancel, azzx)
		}
	}
	for _, azzxc := range CUK.VHProinvite {
		if IsBlockinvite(azzxc) == false {
			proInvite = append(proInvite, azzxc)
		}
	}
}

func AddedBlacklist(from string) {
	if !IsVhTeam(from) {
		if IsBlacklist(from) == false {
			if from != BotsMid {
				VHblacklist = append(VHblacklist, from)
			}
		}
	}
}

func DeleteBlacklist() {
	VHblacklist = []string{}
}

func LockNameGc(groups string) {
	if LockGC == true {
		res, _ := meyar.GetGroup(groups)
		if NameGroups == "" {
			NameGroups = res.Name
			res.Name = "󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳"
			if VHleader == BotsMid {
				meyar.UpdateGroup(res)
			} else {
				if VHleader == "" {
					meyar.UpdateGroup(res)
				}
			}
		}
	}
}

func UnlockNameGc(groups string) {
	if NameGroups != "" {
		res, _ := meyar.GetCompactGroup(groups)
		res.Name = NameGroups
		if VHleader == BotsMid {
			meyar.UpdateGroup(res)
		} else {
			if VHleader == "" {
				meyar.UpdateGroup(res)
			}
		}
		NameGroups = ""
	}
}

func JoinQr(groups string) {
	Warbots = true
	res, _ := meyar.GetCompactGroup(groups)
	res.PreventedJoinByTicket = false
	meyar.UpdateGroup(res)
	anum, _ := meyar.ReissueGroupTicket(res.ID)
	gTicket := "https://line.me/R/ti/g/" + anum
	for _, a := range VHsquad {
		if !IsAjs(a) {
			meyar.SendMessage(a, gTicket, map[string]string{})
		}
	}
	//time.Sleep(time.Second * 1)
	time.Sleep(500 * time.Millisecond)
	res.PreventedJoinByTicket = true
	meyar.UpdateGroup(res)
}
func LockURL(group string) {
	res, _ := meyar.GetCompactGroup(group)
	cek := res.PreventedJoinByTicket
	if cek == true {
		res.PreventedJoinByTicket = true
		go func() {
			LockNameGc(group)
		}()
		go func() {
			meyar.UpdateGroup(res)
		}()
	}
}

func NewPurge(groups string) {
	res, _ := meyar.GetCompactGroup(groups)
	memlist := res.Members
	var LosDol = 0
	for _, v := range memlist {
		anjeng := v.Mid
		if IsBlacklist(anjeng) == true {
			go func(anjeng string) {
				meyar.KickoutFromGroup(groups, []string{anjeng})
			}(anjeng)
			LosDol = LosDol + 1
			if LosDol >= VHbatas {
				LosDol = 0
				break
			}
		}
	}
	for _, vz := range memlist {
		Lope := vz.Mid
		if IsBots(Lope) == true {
			NotInvited = append(NotInvited, Lope)
		}
	}
	for _, Midel := range VHsquad {
		if IsNotInv(Midel) == false {
			NeededInvited = append(NeededInvited, Midel)
		}
	}
}

func InvitedAjs(groups string) {
	if !IsAjs(BotsMid) {
		for _, v := range VHajs {
			if IsPending(v, groups) == true {
				fmt.Println("Hey ho")
			} else {
				if BotsMid == VHleader {
					err := meyar.InviteIntoGroup(groups, VHajs)
					if err != nil {
						VHSendText(groups, "ɪ ʟɪᴍɪᴛ ʙʀᴏ")
					}
				}
			}
		}
	}
}

func IsKillMode(groups string, slayer string, victim string) {
	if IsBots(victim) && !IsVhTeam(slayer) {
		asuk, _ := meyar.GetContact(slayer)
		cokss := asuk.DisplayName
		var str string
		if strings.Contains(cokss, "1") {
			str = strings.Replace(cokss, "1", "", 1)
		} else if strings.Contains(cokss, "2") {
			str = strings.Replace(cokss, "2", "", 1)
		} else if strings.Contains(cokss, "3") {
			str = strings.Replace(cokss, "3", "", 1)
		} else if strings.Contains(cokss, "4") {
			str = strings.Replace(cokss, "4", "", 1)
		} else if strings.Contains(cokss, "5") {
			str = strings.Replace(cokss, "5", "", 1)
		} else if strings.Contains(cokss, "6") {
			str = strings.Replace(cokss, "6", "", 1)
		} else if strings.Contains(cokss, "7") {
			str = strings.Replace(cokss, "7", "", 1)
		} else if strings.Contains(cokss, "8") {
			str = strings.Replace(cokss, "8", "", 1)
		} else if strings.Contains(cokss, "9") {
			str = strings.Replace(cokss, "9", "", 1)
		} else if strings.Contains(cokss, "0") {
			str = strings.Replace(cokss, "0", "", 1)
		} else {
			str = cokss
		}
		res, _ := meyar.GetGroup(groups)
		memlist := res.Members
		cokz := []string{}
		for _, a := range memlist {
			if strings.Contains(a.DisplayName, str) {
				fmt.Println("INI NAMA: " + a.DisplayName)
				fmt.Println("INI STR: " + str)
				cokz = append(cokz, a.Mid)
			} else {
				fmt.Println("Notting")
			}
		}
		for _, v := range cokz {
			if !IsVhTeam(v) {
				if v != BotsMid {
					go func(v string) {
						meyar.KickoutFromGroup(groups, []string{v})
					}(v)
					go func(v string) {
						AddedBlacklist(v)
					}(v)
				}
			}
		}
	}
}
func NotifedURL(groups string, Slayer string) {
	var Fak = []string{Slayer}
	if IsBlacklist(Slayer) == true {
		go func() {
			VHkick(groups, Fak)
		}()
		go func() {
			LockURL(groups)
		}()
	} else if IsBlockqr(groups) == true {
		if !IsVhTeam(Slayer) {
			go func() {
				VHkick(groups, Fak)
			}()
			go func() {
				AddedBlacklist(Slayer)
			}()
			go func() {
				LockURL(groups)
			}()
		}
	}
}
func contains(arr []string, str string) bool{
	for i:=0;i<len(arr);i++{
		if arr[i] == str{
			return true
		}
	}
	return false
}
func uncontains(arr []string, str string) bool{
	for i:=0;i<len(arr);i++{
		if arr[i] == str{
			return false
		}
	}
	return true
}
func checkEqual(list1 []string, list2 []string) bool {
	  looper1 := len(list1)
		looper2 := len(list2)
		for i1:=0;i1<looper1;i1++{
			for i2:=0;i2<looper2;i2++{
				if list1[i1] == list2[i2]{
					 return true
				}
			}
		}
		return false
}
func randomToString(count int) string {
	numb := make([]rune, count)
	for i := range numb {
		numb[i] = stringToInt[rand.Intn(len(stringToInt))]
	}
	return string(numb)
}
func VHinvite(groups string, korban []string) {
	//var batasCok = VHbatas - 1
	for i := range VHbackup {
		if IsMember(VHbackup[i], groups) {
			if BotsMid == VHbackup[i] {
				for _, vo := range korban {
					go func(vo string) {
						meyar.InviteIntoGroup(groups, []string{vo})
					}(vo)
					/*if no >= batasCok {
						break
					} */
				}
			}
			break
		} else {
			continue
		}
	}
}
func VHbackSQ( groups string, mid []string, korban string) {
	grup, _ := meyar.GetGroupV2(groups)
	memb := grup.MemberMids
	for x := range VHbackup {
		if contains(memb, VHbackup[x]) {
			if BotsMid == VHbackup[x] {
				var wg sync.WaitGroup
				wg.Add(1)
				go func() {
					defer wg.Done()
					go meyar.KickoutFromGroup(groups, mid)
				}()
				wg.Add(1)
				go func() {
					defer wg.Done()
					go meyar.InviteIntoGroup(groups, []string{korban})
				}()
				wg.Wait()
			}
			break
		} else {
			continue
		}
	}
	runtime.GOMAXPROCS(20)
}
func VHinvitesq(groups string, korban []string) {
	//var batasCok = VHbatas - 1
	for i := range VHbackup {
		if IsMember(VHbackup[i], groups) {
			if BotsMid == VHbackup[i] {
				meyar.InviteIntoGroup(groups, korban)
				/*if no >= batasCok {
					break
				} */
			}
			break
		} else {
			continue
		}
	}
}
func VHcancel(groups string, korban []string) {
	//var batasCok = VHbatas - 1
	for i := range VHbackup {
		if IsMember(VHbackup[i], groups) {
			if BotsMid == VHbackup[i] {
				for _, vo := range korban {
					go func(vo string) {
						meyar.CancelGroupInvitation(groups, []string{vo})
					}(vo)
					go func(vo string) {
						AddedBlacklist(vo)
					}(vo)
					/*if no >= batasCok {
						break
					} */
				}
			}
			break
		} else {
			continue
		}
	}
}
func VHkick(groups string, korban []string) {
	for i := range VHbackup {
		if IsMember(VHbackup[i], groups) {
			if BotsMid == VHbackup[i] {
				if HardMode == true {
					var batasCok = VHbatas - 1
					for no, vo := range korban {
						no++
						go func(vo string) {
							meyar.KickoutFromGroup(groups, []string{vo})
						}(vo)
						if no >= batasCok {
							break
						}
					}
				}
			}
			break
		} else {
			continue
		}
	}
}
func VHinvted(groups string, korban string) {
	if HardMode == true {
		go func() {
			VHinvitesq(groups, VHsquad)
		}()
	} else {
		VHinvite(groups, []string{korban})
	}
}

func AjsCoks(groups string, slayer string, victim string) {
	runtime.GOMAXPROCS(4)
	if !IsVhTeam(slayer) {
		if IsVhTeam(victim) {
			go func() {
				meyar.AcceptGroupInvitation(groups)
			}()
			JoinQr(groups)
			go func() {
				meyar.FindAndAddContactsByMid(victim)
			}()
			go func() {
				meyar.InviteIntoGroup(groups, []string{victim})
			}()
			go func() {
				meyar.KickoutFromGroup(groups, []string{slayer})
				meyar.LeaveGroup(groups)
			}()
			go func() {
				AddedBlacklist(slayer)
			}()
		}
	} else {
		go func() {
			meyar.AcceptGroupInvitation(groups)
		}()
		JoinQr(groups)
		go func() {
			meyar.FindAndAddContactsByMid(victim)
		}()
		go func() {
			meyar.InviteIntoGroup(groups, []string{victim})
		}()
		go func() {
			meyar.LeaveGroup(groups)
		}()
	}
}

func bot(op *LineThrift.Operation) {
	runtime.GOMAXPROCS(20)
	//fmt.Println(op)
	var groups = op.Param1
	var slayer = op.Param2
	var victim = op.Param3
	var systemLine = op.Type
	if systemLine == 13 || op.Type == 124 {
		//NotifedInvited(op.Param1, op.Param2, op.Param3)
		noodles := strings.Split(victim, "\x1e")
		if IsBots(slayer) && helper.InArray(noodles, BotsMid) {
			if IsAjs(BotsMid) == false {
				go func() {
					go meyar.AcceptGroupInvitation(groups)
					mex,_ := meyar.GetGroup(groups)
					mem := mex.Members
					for _, g := range mem {
						if IsBlacklist(g.Mid) {
							jem := []string{g.Mid}
							go meyar.KickoutFromGroup(groups, jem)
						}
					}
					//NotifUndang[op.Param1] = false
				}()
				//go func() {
					//NewPurge(groups)
				//}()
			}
		}
		if DoRequest("http://127.0.0.1:8000/?cancel"+strconv.FormatInt(op.CreatedTime, 10)) == true {
			if IsKurung(noodles, VHblacklist) && !IsVhTeam(slayer) {
				go func() {
					meyar.KickoutFromGroup(groups, []string{slayer})
				}()
				go func() {
					VHcancel(groups, noodles)
				}()
				go func() {
					VHkick(groups, noodles)
				}()
				go func() {
					AddedBlacklist(slayer)
				}()
				//}
			} else if IsBlacklist(slayer) == true {
				go func() {
					meyar.KickoutFromGroup(groups, []string{slayer})
				}()
				go func() {
					VHcancel(groups, noodles)
				}()
				go func() {
					VHkick(groups, noodles)
				}()
			}
		}
		if IsOwner(slayer) {
			fmt.Println("oke")
			if helper.InArray(noodles, BotsMid) == true {
				go func() {
					Warbots = true
					meyar.AcceptGroupInvitation(groups)
				}()
				if len(VHblacklist) != 0 {
					go func() {
						NewPurge(groups)
					}()
				}
				if ForceQr == true {
					JoinQr(groups)
				}
				if ForceInv == true {
					meyar.InviteIntoGroup(groups, VHsquad)
				}
				if len(VHajs) != 0 {
					if ForceAjs == true {
						go func() {
							InvitedAjs(groups)
						}()
					}
				}
			}
			if helper.InArray(noodles, VHleader) == true {
				Warbots = true
			}
		} else if IsBlockinvite(groups) && !IsVhTeam(slayer) {
			for _, v := range noodles {
				if !IsVhTeam(v) {
					go func(v string) {
						VHcancel(groups, []string{v})
					}(v)
					go func(v string) {
						AddedBlacklist(v)
					}(v)
				}
			}
			go func() {
				meyar.KickoutFromGroup(groups, []string{slayer})
			}()
			go func() {
				AddedBlacklist(slayer)
			}()
		}
	} else if systemLine == 19 || op.Type == 133 {
		runtime.GOMAXPROCS(20)
		korban := op.Param3
		kicker := op.Param2
		group := op.Param1
		if Warbots == true {
			if victim == BotsMid {
				go func() {
					NotifUndang[op.Param1] = true
					AddedBlacklist(slayer)
				}()
				NotInvited = []string{}
				NeededInvited = []string{}
			}
			if DoRequest("http://127.0.0.1:8000/?kick"+strconv.FormatInt(op.CreatedTime, 5)) == true {
				if IsBots(slayer) == true {
					go func() {
						AddedBlacklist(victim)
					}()
				} else if IsBlacklist(slayer) == true {
					VHkick(groups, []string{slayer})
					go func() {
						VHinvted(op.Param1, op.Param3)
					}()
				} else if IsBots(victim) && !IsVhTeam(slayer) {
					go func() {
						VHkick(groups, []string{slayer})
					}()
					VHinvted(op.Param1, op.Param3)
					go func() {
						AddedBlacklist(slayer)
					}()
				} else if IsOwner(victim) {
					go func() {
						meyar.FindAndAddContactsByMid(victim)
					}()
					go func() {
						VHinvite(groups, []string{victim})
					}()
					if !IsVhTeam(slayer) {
						go func() {
							meyar.KickoutFromGroup(groups, []string{slayer})
						}()
						go func() {
							AddedBlacklist(slayer)
						}()
					}
				} else if IsBlockkick(groups) && !IsVhTeam(slayer) {
					go func() {
						meyar.KickoutFromGroup(groups, []string{slayer})
					}()
					go func() {
						AddedBlacklist(slayer)
					}()
					if IsVhTeam(victim) {
						go func() {
							meyar.FindAndAddContactsByMid(victim)
						}()
						go func() {
							VHinvite(groups, []string{victim})
						}()
					}
				} else if KillMode == true {
					IsKillMode(op.Param1, op.Param2, op.Param3)
				}
			}
		}
		if IsAjs(BotsMid) == true {
			go func() {
				AjsCoks(op.Param1, op.Param2, op.Param3)
			}()
		}
		if korban == BotsMid {
			go func() {
				NotifUndang[group] = true
				AddedBlacklist(kicker)
			}()
			NotInvited = []string{}
			NeededInvited = []string{}
		} else if IsBots(korban) && !IsVhTeam(kicker) {
			if Warbots == true {
				go func(){AddedBlacklist(kicker)}()
				go func(){VHbackSQ(group,[]string{kicker},korban)}()
				time.Sleep(500 * time.Nanosecond)
			}
		}
	} else if systemLine == 5 {
		if IsOwner(op.Param1) {
			if IsFriends(op.Param1) == false {
				go func() {
					meyar.FindAndAddContactsByMid(op.Param1)
				}()
			}
		} else if IsFriends(op.Param1) == false {
			if IsBots(op.Param1) == true {
				go func() {
					meyar.FindAndAddContactsByMid(op.Param1)
				}()
			}
		}
	} else if systemLine == 11 || op.Type == 122 {
		if Warbots == true {
			NotifedURL(groups, slayer)
		}
	} else if systemLine == 12 || op.Type == 123 {
		go func() {
			CInvite()
		}()
	} else if systemLine == 15 || op.Type == 128 {
		if IsAjs(slayer) {
			go func() {
				InvitedAjs(groups)
			}()
		}
		if BotsMid == slayer {
			NotifUndang[op.Param1] = true
		}
	} else if systemLine == 16 || op.Type == 129 {
		if len(VHblacklist) != 0 {
			if len(NeededInvited) != 0 {
				go func() {
					meyar.InviteIntoGroup(groups, NeededInvited)
					NotInvited = []string{}
					NeededInvited = []string{}
				}()
			}
		}
	} else if systemLine == 17 || op.Type == 130 {
		if Warbots == true {
			if IsBlacklist(slayer) {
				if DoRequest("http://127.0.0.1:8000/?notifjoin"+strconv.FormatInt(op.CreatedTime, 5)) == true {
					go func() {
						meyar.KickoutFromGroup(groups, []string{slayer})
					}()
				}
			}
		}
	} else if systemLine == 18 || op.Type == 132 {
		go func() {
			CountKick()
		}()
	} else if systemLine == 31 || op.Type == 125 {
		go func() {
			CCancel()
		}()
	} else if systemLine == 32 || op.Type == 126 {
		//if DoRequest("http://127.0.0.1:8000/?notifcancel"+strconv.FormatInt(op.CreatedTime, 10)) == true {
		if victim == BotsMid {
			go func() {
				AddedBlacklist(slayer)
			}()
			return
		}
		if DoRequest("http://127.0.0.1:8000/?notifcancel"+strconv.FormatInt(op.CreatedTime, 5)) == true {
			if IsBlacklist(slayer) == true {
				go func() {
					VHkick(groups, []string{slayer})
				}()
				VHinvted(op.Param1, op.Param3)
			} else if IsBots(victim) && !IsVhTeam(slayer) {
				go func() {
					VHkick(groups, []string{slayer})
				}()
				VHinvted(op.Param1, op.Param3)
				go func() {
					AddedBlacklist(slayer)
				}()
			} else if IsBots(slayer) == true {
				go func() {
					AddedBlacklist(victim)
				}()
			} else if IsOwner(victim) == true {
				go func() {
					meyar.FindAndAddContactsByMid(victim)
				}()
				go func() {
					VHinvite(groups, []string{victim})
				}()
				go func() {
					VHkick(groups, []string{slayer})
				}()
				go func() {
					AddedBlacklist(slayer)
				}()
			} else if IsBlockcancel(groups) && !IsVhTeam(slayer) {
				go func() {
					meyar.KickoutFromGroup(groups, []string{slayer})
				}()
				go func() {
					AddedBlacklist(slayer)
				}()
			} else if IsAjs(victim) && !IsVhTeam(slayer) {
				go func() {
					VHinvite(groups, []string{victim})
				}()
				JoinQr(groups)
				go func() {
					VHkick(groups, []string{slayer})
				}()
			}
		}
	} else if systemLine == 55 {
		var data, _ = ioutil.ReadFile(VHBOTS)
		var setting Settings
		json.Unmarshal(data, &setting)
		if siderV2[op.Param1] == true {
			if helper.InArray(sider[op.Param1], op.Param2) == false {
				if !IsOwner(op.Param2) {
					if VHleader == BotsMid {
						asu := "@!"
						if strings.Contains(setting.Msgsider, "%v") {
							haniKu := fmt.Sprintf(setting.Msgsider, asu)
							meyar.SendMentionVH(op.Param1, haniKu, []string{op.Param2})
						} else {
							meyar.SendMentionVH(op.Param1, "هل بامكانك التحدث داخل المجموعة @!", []string{op.Param2})
						}
						sider[op.Param1] = append(sider[op.Param1], op.Param2)
					}
				}
			}
		}
	} else if systemLine == 26 {
		var MentionMsg = MentionList(op)
		var data, _ = ioutil.ReadFile(VHBOTS)
		var setting Settings
		json.Unmarshal(data, &setting)
		msg := op.Message
		var pesan = strings.ToLower(msg.Text)
		if strings.Contains(pesan, "/ti/g") {
			if IsHani(msg.From_) {
				regex, _ := regexp.Compile(`(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?`)
				links := regex.FindAllString(msg.Text, -1)
				tickets := []string{}
				gids, _ := meyar.GetGroupIdsJoined()
				for _, link := range links {
					if !helper.InArray(tickets, link) {
						tickets = append(tickets, link)
					}
				}
				for _, tick := range tickets {
					tuk := strings.Split(tick, "/")
					ntk := len(tuk) - 1
					ticket := tuk[ntk]
					acc, err := meyar.FindGroupByTicket(ticket)
					if err != nil {
						continue
					} else {
						ids := acc.ID
						if helper.InArray(gids, ids) {
							continue
						} else {
							if TimeDown(PosisiAsist) == true {
								DeleteBlacklist()
								BackupVH()
								et := meyar.AcceptGroupInvitationByTicket(ids, ticket)
								if et != nil {
									fmt.Println(et)
								}
							} else {
								DeleteBlacklist()
								BackupVH()
								et := meyar.AcceptGroupInvitationByTicket(ids, ticket)
								if et != nil {
									fmt.Println(et)
								}
							}
							if IsAjs(BotsMid) == true {
								DeleteAjs()
							}
						}
					}
				}
			}
		} else if strings.Contains(pesan, "qwerty") {
			haniku := strings.ReplaceAll(pesan, "qwerty", "")
			fmt.Println(haniku)
			StatusAsist = append(StatusAsist, haniku)
		} else if strings.Contains(pesan, "speedku") {
			haniku := strings.ReplaceAll(pesan, "speedku", "")
			fmt.Println(haniku)
			StatusAsist = append(StatusAsist, haniku)
		} else if strings.Contains(pesan, "kicount") {
			haniku := strings.ReplaceAll(pesan, "kicount", "")
			no, _ := strconv.Atoi(haniku)
			rinQ := Akick + no
			Akick = rinQ
		} else if strings.Contains(pesan, "incount") {
			haniku := strings.ReplaceAll(pesan, "incount", "")
			no, _ := strconv.Atoi(haniku)
			rinQ := Ainvite + no
			Ainvite = rinQ
		} else if strings.Contains(pesan, "cacount") {
			haniku := strings.ReplaceAll(pesan, "cacount", "")
			no, _ := strconv.Atoi(haniku)
			rinQ := Acancel + no
			Acancel = rinQ
		}
		var Mid = BotsMid
		var cmds = []string{}
		if IsVhTeam(msg.From_) {
			var sname = setting.Sname
			//var KeyBots = sname+" || "+rname
			var txt string
			var NameTeam = VHtitle()
			var lgo = VHlogo()
			var Team = VHmids()
			var silent = false
			var Tcm = []string{}
			var scikon = msg.ContentMetadata["REPLACE"]
			sender := msg.From_
			receiver := msg.To
			var to = sender
			if msg.ToType == 0 {
				to = sender
			} else {
				to = receiver
			}
			if msg.ToType == 1 {
				to = receiver
			}
			if msg.ToType == 2 {
				to = receiver
			}
			if msg.RelatedMessageId != "" {
				MentionMsg = getreply(op)
			}
			if scikon != "" {
				if ChangeStk == true {
					res := helper.SticonCok{}
					json.Unmarshal([]byte(scikon), &res)
					for _, v := range res.Sticon.Resources {
						anu := v.ProductID
						anumu := v.SticonID
						stk := string(anu) + "|" + string(anumu)
						AddedStkComs(HelpStk, stk)
					}
					Tcm = append(Tcm, "Saved sticker "+HelpStk)
					ChangeStk = false
				} else {
					res := helper.SticonCok{}
					json.Unmarshal([]byte(scikon), &res)
					for _, v := range res.Sticon.Resources {
						anu := v.ProductID
						anumu := v.SticonID
						stk := string(anu) + "|" + string(anumu)
						cmds = mystk(stk)
					}
				}
			} else if msg.ContentType == 7 {
				if ChangeStk == true {
					anu := msg.ContentMetadata["STKID"]
					anumu := msg.ContentMetadata["STKPKGID"]
					stk := string(anu) + "|" + string(anumu)
					AddedStkComs(HelpStk, stk)
					Tcm = append(Tcm, "Saved sticker "+HelpStk)
					ChangeStk = false
				} else {
					anu := msg.ContentMetadata["STKID"]
					anumu := msg.ContentMetadata["STKPKGID"]
					stk := string(anu) + "|" + string(anumu)
					cmds = mystk(stk)
				}
			}
			if strings.HasPrefix(pesan, rname) || strings.HasPrefix(pesan, sname) {
				if strings.Contains(pesan, "r:") {
					pesan = strings.Replace(pesan, rname, "", 1)
					pesan = strings.Replace(pesan, sname, "", 1)
					pesan = strings.TrimPrefix(pesan, " ")
					pesan = strings.Replace(pesan, "r:", "", 1)
					nums := strings.Split(pesan, " ")
					st := nums[0]
					pesan = strings.Replace(pesan, st, "", 1)
					pesan = rname + pesan
					numb, _ := strconv.Atoi(st)
					numb = numb - 1
					fmt.Println(numb)
					cmds = mycmd(pesan, rname, sname, Mid, MentionMsg)
				}
			}
			if pesan == "sname" {
				VHSendText(to, setting.Sname)
			} else if pesan == "rname" {
				anu := PosisiAsist
				if TimeDown(anu) == true {
					meyar.SendMessage(to, rname, map[string]string{})
				} else {
					meyar.SendMessage(to, rname, map[string]string{})
				}
			} else if pesan == "respon" {
				anu := PosisiAsist
				if TimeDown(anu) == true {
					meyar.SendMessage(to, setting.Responbot, map[string]string{})
				} else {
					meyar.SendMessage(to, setting.Responbot, map[string]string{})
				}
			} else if pesan == setting.Sname {
				Tcm = append(Tcm, setting.Responbot)
			} else if pesan == rname {
				meyar.SendMessage(to, setting.Responbot, map[string]string{})
			} else {
				if strings.Contains(pesan, ".silent") {
					pesan = strings.Replace(pesan, ".silent", "", 1)
					pesan = strings.TrimSuffix(pesan, " ")
					silent = true
				}
				if msg.ContentType == 0 && msg.Text != "" {
					if strings.HasPrefix(pesan, rname) || strings.HasPrefix(pesan, sname) || helper.InArray(MentionMsg, Mid) || strings.HasPrefix(pesan, "!") {
						cmds = mycmd(pesan, rname, sname, Mid, MentionMsg)
					}
				}
			}
			for _, mcom := range cmds {
				txt = mcom
				fmt.Println(txt)
				if txt == "mid" {
					Tcm = append(Tcm, sender)
				} else if txt == "test" {
					Tcm = append(Tcm, "Cok jaran")
				} else if txt == CHelp || txt == "help" || txt == SHelp {
					if IsStaff(msg.From_) {
						rinku := ""
						if VHleader != "" {
							rinku += sname
						} else {
							rinku += sname + " / " + rname
						}
						a := lgo + " --- 𝗦𝘁𝗮𝗳𝗳 𝗚𝘂𝗶𝗱𝗲 --- " + lgo + "\n"
						a += "\n1. " + rinku + " help"
						a += "\n2. " + rinku + " about"
						a += "\n2. " + rinku + " grade"
						a += "\n3. " + rinku + " tagall"
						a += "\n4. " + rinku + " clear temp"
						a += "\n5. " + rinku + " keymap"
						a += "\n6. " + rinku + " setbot"
						a += "\n7. " + rinku + " respon "
						a += "\n8. " + rinku + " banlist "
						a += "\n9. " + rinku + " cban "
						a += "\n\n  -- 𝗣𝗿𝗼𝘁𝗲𝗰𝘁𝗶𝗼𝗻 --\n"
						a += "\n1. " + rinku + " ajs stay"
						a += "\n2. " + rinku + " check ajs"
						a += "\n3. " + rinku + " locknamegc on/off"
						a += "\n4. " + rinku + " blockkick on/off"
						a += "\n5. " + rinku + " blockqr on/off"
						a += "\n6. " + rinku + " blockcancel on/off"
						a += "\n7. " + rinku + " blockinvite on/off"
						a += "\n8. " + rinku + " promax on/off"
						a += "\n\n  -- 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻 --\n"
						a += "\n  This menu is only for staff"
						a += "\n\n𝗦𝗲𝘁𝗸𝗲𝘆:\n    Sname / " + sname
						a += "\n    Rname / " + rname
						a += "\n\n𝗠𝘂𝗹𝘁𝗶 𝗰𝗼𝗺𝗺𝗮𝗻𝗱: " + sname + "「command,」"
						a += "\n\n@𝗠𝗲𝗻𝘁𝗶𝗼𝗻: 「your command」"
						a += "\n𝗥𝗲𝗽𝗹𝘆: 「your command」"
						Tcm = append(Tcm, a)
					}
				} else if txt == "ajs stay" || txt == "blockjs on" {
					if IsAjs(BotsMid) == true {
						meyar.LeaveGroup(to)
					} else {
						InvitedAjs(to)
					}
				} else if txt == "check ajs" || txt == "cek ajs" {
					res, _ := meyar.GetGroup(to)
					memlist := res.Invitee
					for _, v := range memlist {
						if IsAjs(v.Mid) {
							Tcm = append(Tcm, "Antijs be in a group invited")
						}
					}
				} else if txt == "about" {
					o, _ := host.Info()
					m, _ := mem.VirtualMemory()
					d, _ := disk.Usage("/")
					r, _ := api.GetRunningVersion()
					OS := fmt.Sprintf("%v - Ubuntu %v ", o.OS, o.PlatformVersion)
					CPU := fmt.Sprintf("%v", runtime.NumCPU())
					RAM := fmt.Sprintf("%v", m.Total)
					Sakura := m.UsedPercent + d.UsedPercent
					RAMused := fmt.Sprintf("%v", Sakura)
					Gover := fmt.Sprintf("%v", r.Version)
					Gplat := fmt.Sprintf("%v", r.Platform)
					Garch := fmt.Sprintf("%v", r.Architecture)
					ancokf, _ := meyar.GetAllContactIds()
					Friends := fmt.Sprintf("%v", len(ancokf))
					ancokg, _ := meyar.GetGroupIdsJoined()
					Groups := fmt.Sprintf("%v", len(ancokg))
					vezaS, _ := meyar.GetSettings()
					aler := ""
					if vezaS.E2eeEnable == true {
						aler += "✔️ on"
					} else {
						aler += "✘ off"
					}
					a := "Dev: @!"
					a += "\n\n𝗕𝗼𝘁 𝗶𝗻𝗳𝗼:"
					a += "\n  " + lgo + " Version: " + Version
					a += "\n  " + lgo + " Type: Multi fetch"
					a += "\n  " + lgo + " Base: " + config.USER_AGENT
					a += "\n  " + lgo + " Lang: Go"
					a += "\n\n𝗔𝗰𝗰𝗼𝘂𝗻𝘁 𝗶𝗻𝗳𝗼:"
					a += "\n  • Friend: " + Friends
					a += "\n  • Groups: " + Groups
					a += "\n  • LtSealing: " + aler
					a += "\n\n𝗟𝗮𝗻𝗴 𝗶𝗻𝗳𝗼:"
					a += "\n  # Go Version: " + Gover
					a += "\n  # Go Platform: " + Gplat
					a += "\n  # Go Architecture: " + Garch
					a += "\n\n𝗦𝗲𝗿𝘃𝗲𝗿 𝗶𝗻𝗳𝗼:"
					a += "\n  * OS: " + OS
					a += "\n  * CPU: " + CPU + " Core"
					a += "\n  * RAM: " + RAM[:1] + " Gb"
					a += "\n  * Mem-𝗨𝘀𝗲𝗱: " + RAMused[:2] + "%"
					a += "\n  * LoginIp: " + config.IPCOK
					asw := []string{"u9b9897fdd536e9886a4b7c28def482cf"}
					if VHleader != "" {
						VHSendMention(msg.ID, to, a, asw, "  SELFTCR™ 2022", "https://s20.directupload.net/images/220423/uxdxnp5a.jpg", "https://line.me/ti/p/~j71.a")
					} else {
						Tcm = append(Tcm, "Not have leads")
					}
				} else if txt == "grade" {
                               a := "MyCreator:\n @!"
                               a += "\n" + lgo + "--𝗚𝗿𝗮𝗱𝗲𝗟𝗶𝘀𝘁--" + lgo + "\n"
				      a += "\n  • MasterList: " + strconv.Itoa(len(VHcreator))
				      a += "\n  • OwnerList: " + strconv.Itoa(len(VHowner))
                               a += "\n  • StaffList: " + strconv.Itoa(len(VHstaff))
                               a += "\n  • BotList: " + strconv.Itoa(len(VHsquad))
                               a += "\n  • SquadList: " + strconv.Itoa(len(VHbackup))
                               a += "\n  • AjsList: " + strconv.Itoa(len(VHajs))
					asw := []string{"u9b9897fdd536e9886a4b7c28def482cf"}
					if VHleader != "" {
						VHSendMention(msg.ID, to, a, asw, "  SELFTCR™ 2022", "https://s20.directupload.net/images/220423/uxdxnp5a.jpg", "https://line.me/ti/p/~j71.a")
					} else {
						Tcm = append(Tcm, "Not have leads")
					}
				} else if txt == "banlist" || txt == SListban || txt == CListban {
					if len(VHblacklist) != 0 {
						a := lgo + "---- List Banned ----" + lgo + "\n"
						for jaran, cok := range VHblacklist {
							jaran++
							VezaGanteng := strconv.Itoa(jaran)
							fmt.Println(cok)
							a += "\n* " + VezaGanteng + ". @!"
						}
						a += "\n\nAmount: " + strconv.Itoa(len(VHblacklist)) + " Son of a bitch"
						VHSendMention(msg.ID, to, a, VHblacklist, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
					} else {
						Tcm = append(Tcm, "ᴅᴏɴᴛ ʜᴀᴠᴇ ʙᴀɴ ʟɪsᴛ")
					}
				} else if txt == "cban" || txt == SClearbans || txt == CClearbans {
					if len(VHblacklist) != 0 {
						jaran := len(VHblacklist)
						asu := strconv.Itoa(jaran)
						if strings.Contains(setting.Msgclearbans, "%v") {
							haniKu := fmt.Sprintf(setting.Msgclearbans, asu)
							Tcm = append(Tcm, haniKu)
						} else {
							Tcm = append(Tcm, "ᴅᴏɴᴇ ʀᴇᴍᴏᴠᴇ "+asu+" ɪɴ ʙᴀɴ")
						}
						DeleteBlacklist()
						if NameGroups != "" {
							UnlockNameGc(to)
						}
					} else {
						VHSendMention(msg.ID, to, "ɴᴏᴛ ʜᴀᴠᴇ ʙᴀɴ ʟɪsᴛ @! ௸", []string{sender}, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
					}
				} else if txt == "blockqr on" || txt == "proqr on" {
					if !IsBlockqr(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProqr = append(data2.VHProqr, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proQr = append(proQr, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ǫʀ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏɴ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏɴ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockqr off" || txt == "proqr off" {
					if IsBlockqr(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProqr = helper.Remove(data2.VHProqr, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proQr = helper.Remove(proQr, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ǫʀ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏғғ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏғғ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockkick on" || txt == "prokick on" {
					if !IsBlockkick(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProkick = append(data2.VHProkick, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proKick = append(proKick, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ᴋɪᴄᴋ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏɴ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏɴ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockkick off" || txt == "prokick off" {
					if IsBlockkick(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProkick = helper.Remove(data2.VHProkick, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proKick = helper.Remove(proKick, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ᴋɪᴄᴋ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏғғ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏғғ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockinvite on" || txt == "proinvite on" {
					if !IsBlockinvite(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProinvite = append(data2.VHProinvite, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proInvite = append(proInvite, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ɪɴᴠɪᴛᴇ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏɴ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏɴ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockinvite off" || txt == "proinvite off" {
					if IsBlockinvite(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProinvite = helper.Remove(data2.VHProinvite, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proInvite = helper.Remove(proInvite, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ɪɴᴠɪᴛᴇ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏғғ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏғғ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockcancel on" || txt == "procancel on" {
					if !IsBlockcancel(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProcancel = append(data2.VHProcancel, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proCancel = append(proCancel, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ᴄᴀɴᴄᴇʟ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏɴ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏɴ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "blockcancel off" || txt == "procancel off" {
					if IsBlockcancel(to) {
						if VHleader == BotsMid {
							file2, _ := ioutil.ReadFile(VHBOTS)
							data2 := Settings{}
							json.Unmarshal(file2, &data2)
							data2.VHProcancel = helper.Remove(data2.VHProcancel, to)
							dataBytes2, _ := json.MarshalIndent(data2, "", " ")
							ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
							proCancel = helper.Remove(proCancel, to)
							res, _ := meyar.GetGroup(to)
							namaGc := res.Name
							Tcm = append(Tcm, "ᴄᴀɴᴄᴇʟ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏғғ")
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						Tcm = append(Tcm, "ɪᴛ’s ʙᴇᴇɴ ᴛᴜʀɴᴇᴅ ᴏғғ ʙᴇғᴏʀ,ʙʀᴏ")
					}
				} else if txt == "promax off" || txt == "protect off" {
					if VHleader == BotsMid {
						file2, _ := ioutil.ReadFile(VHBOTS)
						data2 := Settings{}
						json.Unmarshal(file2, &data2)
						data2.VHProinvite = helper.Remove(data2.VHProinvite, to)
						data2.VHProcancel = helper.Remove(data2.VHProcancel, to)
						data2.VHProkick = helper.Remove(data2.VHProkick, to)
						data2.VHProqr = helper.Remove(data2.VHProqr, to)
						dataBytes2, _ := json.MarshalIndent(data2, "", " ")
						ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
						proInvite = helper.Remove(proInvite, to)
						proKick = helper.Remove(proKick, to)
						proCancel = helper.Remove(proCancel, to)
						proQr = helper.Remove(proQr, to)
						res, _ := meyar.GetGroup(to)
						namaGc := res.Name
						Tcm = append(Tcm, "ᴀʟʟ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏғғ")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if txt == "promax on" || txt == "protect on" {
					if VHleader == BotsMid {
						file2, _ := ioutil.ReadFile(VHBOTS)
						data2 := Settings{}
						json.Unmarshal(file2, &data2)
						data2.VHProinvite = append(data2.VHProinvite, to)
						data2.VHProcancel = append(data2.VHProcancel, to)
						data2.VHProkick = append(data2.VHProkick, to)
						data2.VHProqr = append(data2.VHProqr, to)
						dataBytes2, _ := json.MarshalIndent(data2, "", " ")
						ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
						proInvite = append(proInvite, to)
						proKick = append(proKick, to)
						proCancel = append(proCancel, to)
						proQr = append(proQr, to)
						res, _ := meyar.GetGroup(to)
						namaGc := res.Name
						Tcm = append(Tcm, "ᴀʟʟ ᴘʀᴏ ɪɴ "+namaGc+" sᴇᴛ ᴛᴏ ᴏɴ")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if txt == "lock group" {
					res, _ := meyar.GetGroup(to)
					NameGroups = res.Name
					res.Name = "󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳󾸳"
					if VHleader == BotsMid {
						meyar.UpdateGroup(res)
					} else {
						if VHleader == "" {
							meyar.UpdateGroup(res)
						}
					}
					LockURL(to)
					Tcm = append(Tcm, "Lock "+NameGroups+" enable✔️")
				} else if txt == "unlock group" {
					res, _ := meyar.GetGroup(to)
					res.Name = NameGroups
					if VHleader == BotsMid {
						meyar.UpdateGroup(res)
					} else {
						if VHleader == "" {
							meyar.UpdateGroup(res)
						}
					}
					NameGroups = ""
					LockURL(to)
					Tcm = append(Tcm, "Unlocked "+NameGroups+"")
				} else if txt == "tagall" || txt == "mention" {
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					i := 1
					ta := false
					no := 1
					tx := ""
					tag := []string{}
					for _, v := range memlist {
						cancel := v.Mid
						if !ta {
							tx += "「 • MENTIONALL • 」\n\n"
							ta = true
						}
						if i < 20 {
							tx += fmt.Sprintf("   › %v. @!\n", no)
							no += 1
							i += 1
							tag = append(tag, cancel)
						} else {
							tag = append(tag, cancel)
							tx += fmt.Sprintf("   › %v. @!\n", no)
							res, _ := meyar.GetGroup(to)
							VHSendMention(msg.ID, to, tx, tag, res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
							tag = []string{}
							tx = ""
							i = 1
							no += 1
						}
					}
					if len(tag) != 0 {
						res, _ := meyar.GetGroup(to)
						VHSendMention(msg.ID, to, tx, tag, res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
					}
				} else if txt == "setbot" || txt == CSet || txt == SSet {
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					var VHku = []string{}
					for _, v := range memlist {
						if IsBots(v.Mid) == true {
							VHku = append(VHku, v.Mid)
						}
					}
					anu := len(VHku) + 1
					anumu := len(VHsquad) + 1
					a := lgo + "- Configuration -" + lgo + "\n"
					Vendi := fmt.Sprintf("%v", VHbatas)
					if HardMode == true {
						a += "\n  ✅ ʜᴀʀᴅ ᴍᴏᴅᴇ"
					} else {
						a += "\n  ❌ ʜᴀʀᴅ ᴍᴏᴅᴇ"
					}
					if KillMode == true {
						a += "\n  ✅ ᴋɪʟʟ ᴍᴏᴅᴇ"
					} else {
						a += "\n  ❌ ᴋɪʟʟ ᴍᴏᴅᴇ"
					}
					if PurgeV2 == true {
						a += "\n  ✅ ᴀᴜᴛᴏ ᴘᴜʀɢᴇ"
					} else {
						a += "\n  ❌ ᴀᴜᴛᴏ ᴘᴜʀɢᴇ"
					}
					if AutoClearbans == true {
						a += "\n  ✅ ᴀᴜᴛᴏ ᴄʟᴇᴀʀʙᴀɴs"
					} else {
						a += "\n  ❌ ᴀᴜᴛᴏ ᴄʟᴇᴀʀʙᴀɴs"
					}
					if ForceQr == true {
						a += "\n  ✅ ғᴏʀᴄᴇ ǫʀ"
					} else {
						a += "\n  ❌ ғᴏʀᴄᴇ ǫʀ"
					}
					if ForceInv == true {
						a += "\n  ✅ ғᴏʀᴄᴇ ɪɴᴠ"
					} else {
						a += "\n  ❌ ғᴏʀᴄᴇ ɪɴᴠ"
					}
					if ForceAjs == true {
						a += "\n  ✅ ғᴏʀᴄᴇ ᴀᴊs"
					} else {
						a += "\n  ❌ ғᴏʀᴄᴇ ᴀᴊs"
					}
					if LockGC == true {
						a += "\n  ✅ ʟᴏᴄᴇ ɴᴀᴍᴇɢᴄ"
					} else {
						a += "\n  ❌ ʟᴏᴄᴇ ɴᴀᴍᴇɢᴄ"
					}
					if IsBlockqr(to) == true {
						a += "\n  ✅ ʙʟᴏᴄᴋ ǫʀ"
					} else {
						a += "\n  ❌ ʙʟᴏᴄᴋ ǫʀ"
					}
					if IsBlockkick(to) == true {
						a += "\n  ✅ ʙʟᴏᴄᴋ ᴋɪᴄᴋ"
					} else {
						a += "\n  ❌ ʙʟᴏᴄᴋ ᴋɪᴄᴋ"
					}
					if IsBlockinvite(to) == true {
						a += "\n  ✅ ʙʟᴏᴄᴋ ɪɴᴠɪᴛᴇ"
					} else {
						a += "\n  ❌ ʙʟᴏᴄᴋ ɪɴᴠɪᴛᴇ"
					}
					if IsBlockcancel(to) == true {
						a += "\n  ✅ ʙʟᴏᴄᴋ ᴄᴀɴᴄᴇʟ"
					} else {
						a += "\n  ❌ ʙʟᴏᴄᴋ ᴄᴀɴᴄᴇʟ"
					}
					if IsBlockcancel(to) == true && IsBlockkick(to) == true && IsBlockinvite(to) == true && IsBlockqr(to) == true {
						a += "\n  ✅ ᴍᴀx ᴘʀᴏᴛᴇᴄᴛ"
					} else {
						a += "\n  ❌ ᴍᴀx ᴘʀᴏᴛᴇᴄᴛ"
					}
					a += "\n\nMax excute: " + Vendi
					a += "\nAsist: " + strconv.Itoa(anumu) + "/Here " + strconv.Itoa(anu)
					a += "\n\n" + lgo + "- CreatorMe -" + lgo + "\n"
					a += "\n  @! "
					asw := []string{Team}
					Tcm = append(Tcm)
					VHSendMention(msg.ID, to, a, asw, "Group: "+res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
				} else if txt == "set akun" || txt == "set account" || txt == "status account" {
					a := "Config account:"
					veza, _ := meyar.GetSettings()
					if veza.E2eeEnable == true {
						a += "\n  ✅ ʟᴇᴀᴛᴇʀ sᴇᴀʟɪɴɢ"
					} else {
						a += "\n  ❌  ʟᴇᴀᴛᴇʀ sᴇᴀʟɪɴɢ"
					}
					if veza.PrivacyReceiveMessagesFromNotFriend == true {
						a += "\n  ✅ ғɪʟᴛᴇʀ ᴀᴄᴄᴏᴜɴᴛ"
					} else {
						a += "\n  ❌  ғɪʟᴛᴇʀ ᴀᴄᴄᴏᴜɴᴛ"
					}
					if veza.PrivacyAllowSecondaryDeviceLogin == true {
						a += "\n  ✅ sᴇᴄᴏɴᴅᴀʀʏ ʟᴏɢɪɴ"
					} else {
						a += "\n  ❌  sᴇᴄᴏɴᴅᴀʀʏ ʟᴏɢɪɴ"
					}
					if veza.PrivacySyncContacts != false {
						a += "\n  ✅ ᴇᴍᴀɪʟ ᴄᴏɴғɪʀᴍ"
					} else {
						a += "\n  ❌  ᴇᴍᴀɪʟ ᴄᴏɴғɪʀᴍ"
					}
					a += "\n\nᴍʏ ᴄʀᴇᴀᴛᴏʀ: \n    @! "
					asw := []string{Team}
					res, _ := meyar.GetGroup(to)
					VHSendMention(msg.ID, to, a, asw, "Group: "+res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
				} else if txt == "respon" || txt == CRespon || txt == SRespon {
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					for _, v := range memlist {
						if v.Mid == VHleader {
							VHAssistMessage(to, setting.Responbot)
							Warbots = true
						}
					}
					if VHleader == BotsMid {
						meyar.SendMessage(to, setting.Responbot, map[string]string{})
					}
					if VHleader == "" {
						Warbots = true
					}
				}
			}
			if len(Tcm) != 0 {
				strs := strings.Join(Tcm, ",\n")
				fmt.Println(strs)
				if !silent {
					if strs != "" {
						if VHleader == BotsMid {
							meyar.SendFooter(msg.ID, to, strs, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
						} else {
							if VHleader == "" {
								meyar.SendFooter(msg.ID, to, strs, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
							}
						}
					}
				}
				Tcm = []string{}
			}
		}
		if IsOwner(msg.From_) {
			var sname = setting.Sname
			//var KeyBots = sname+" || "+rname
			var txt string
			var NameTeam = VHtitle()
			var lgo = VHlogo()
			var silent = false
			var Tcm = []string{}
			var scikon = msg.ContentMetadata["REPLACE"]
			sender := msg.From_
			receiver := msg.To
			var to = sender
			if msg.ToType == 0 {
				to = sender
			} else {
				to = receiver
			}
			if msg.ToType == 1 {
				to = receiver
			}
			if msg.ToType == 2 {
				to = receiver
			}
			if msg.RelatedMessageId != "" {
				MentionMsg = getreply(op)
				if pesan == "kick" || pesan == CKick {
					if CKick != "" {
						for _, v := range MentionMsg {
							if !IsVhTeam(v) {
								res, _ := meyar.GetGroup(to)
								VHSendMention(msg.ID, to, "sᴇᴇ ʏᴏᴜ ʙʀᴏ @! ", []string{v}, "  "+res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
								err := meyar.KickoutFromGroup(to, []string{v})
								if err != nil {
									fmt.Println(err)
									meyar.SendMessage(to, "sᴏʀʀʏ ɪ ʟɪᴍɪᴛ !!!", map[string]string{})
								} else if err == nil {
									if v != BotsMid {
										AddedBlacklist(v)
									}
								}
							}
						}
					}
				}
				if msg.ContentType == 7 {
					anu := msg.ContentMetadata["STKID"]
					anumu := msg.ContentMetadata["STKPKGID"]
					stk := string(anu) + "|" + string(anumu)
					if stk == SKick {
						for _, v := range MentionMsg {
							if !IsVhTeam(v) {
								err := meyar.KickoutFromGroup(to, []string{v})
								if err != nil {
									fmt.Println(err)
									meyar.SendMessage(to, "sᴏʀʀʏ ɪ ʟɪᴍɪᴛ !!!", map[string]string{})
								} else if err == nil {
									if v != BotsMid {
										AddedBlacklist(v)
									}
								}
							}
						}
					}
				}
				if scikon != "" {
					res := helper.SticonCok{}
					json.Unmarshal([]byte(scikon), &res)
					for _, v := range res.Sticon.Resources {
						anu := v.ProductID
						anumu := v.SticonID
						stk := string(anu) + "|" + string(anumu)
						fmt.Println(stk)
						if stk == SKick {
							for _, v := range MentionMsg {
								if !IsVhTeam(v) {
									err := meyar.KickoutFromGroup(to, []string{v})
									if err != nil {
										fmt.Println(err)
										meyar.SendMessage(to, "sᴏʀʀʏ ɪ ʟɪᴍɪᴛ !!!", map[string]string{})
									} else if err == nil {
										if v != BotsMid {
											AddedBlacklist(v)
										}
									}
								}
							}
						}
					}
				}
			}
			if strings.HasPrefix(pesan, rname) || strings.HasPrefix(pesan, sname) {
				if strings.Contains(pesan, "r:") {
					pesan = strings.Replace(pesan, rname, "", 1)
					pesan = strings.Replace(pesan, sname, "", 1)
					pesan = strings.TrimPrefix(pesan, " ")
					pesan = strings.Replace(pesan, "r:", "", 1)
					nums := strings.Split(pesan, " ")
					st := nums[0]
					pesan = strings.Replace(pesan, st, "", 1)
					pesan = rname + pesan
					numb, _ := strconv.Atoi(st)
					numb = numb - 1
					fmt.Println(numb)
					cmds = mycmd(pesan, rname, sname, Mid, MentionMsg)
				}
			}
			if scikon != "" {
				if ChangeStk == true {
					res := helper.SticonCok{}
					json.Unmarshal([]byte(scikon), &res)
					for _, v := range res.Sticon.Resources {
						anu := v.ProductID
						anumu := v.SticonID
						fmt.Println(v)
						stk := string(anu) + "|" + string(anumu)
						AddedStkComs(HelpStk, stk)
					}
					Tcm = append(Tcm, "Saved sticker "+HelpStk)
					ChangeStk = false
				} else {
					res := helper.SticonCok{}
					json.Unmarshal([]byte(scikon), &res)
					for _, v := range res.Sticon.Resources {
						anu := v.ProductID
						anumu := v.SticonID
						stk := string(anu) + "|" + string(anumu)
						cmds = mystk(stk)
					}
				}
			} else if msg.ContentType == 7 {
				if ChangeStk == true {
					anu := msg.ContentMetadata["STKID"]
					anumu := msg.ContentMetadata["STKPKGID"]
					stk := string(anu) + "|" + string(anumu)
					AddedStkComs(HelpStk, stk)
					Tcm = append(Tcm, "Saved sticker "+HelpStk)
					ChangeStk = false
				} else {
					anu := msg.ContentMetadata["STKID"]
					anumu := msg.ContentMetadata["STKPKGID"]
					stk := string(anu) + "|" + string(anumu)
					cmds = mystk(stk)
				}
			} else {
				if strings.Contains(pesan, ".silent") {
					pesan = strings.Replace(pesan, ".silent", "", 1)
					pesan = strings.TrimSuffix(pesan, " ")
					silent = true
				}
				if msg.ContentType == 0 && msg.Text != "" {
					if strings.HasPrefix(pesan, rname) || strings.HasPrefix(pesan, sname) || helper.InArray(MentionMsg, Mid) || strings.HasPrefix(pesan, "!") {
						cmds = mycmd(pesan, rname, sname, Mid, MentionMsg)
					}
				}
			}
			for _, mcom := range cmds {
				txt = mcom
				if txt == "" {
					fmt.Println("DMSHQI")
				} else if txt == CHelp || txt == "help" || txt == SHelp {
					rinku := ""
					if VHleader != "" {
						rinku += sname
					} else {
						rinku += sname + " / " + rname
					}
					a := lgo + " --- 𝗛𝗲𝗹𝗽 𝗖𝗼𝗺𝗺𝗮𝗻𝗱 --- " + lgo + "\n"
					a += "\n › respon"
					a += "\n › sname"
					a += "\n › rname"
					a += "\n\n  -- 𝗢𝘄𝗻𝗲𝗿 𝗚𝘂𝗶𝗱𝗲 --\n"
					a += "\n › " + rinku + " about"
					a += "\n › " + rinku + " autoname"
					a += "\n › " + rinku + " updatepict"
					a += "\n › " + rinku + " updatevideo"
					a += "\n › " + rinku + " updatecover"
					a += "\n › " + rinku + " uprname: [text]"
					a += "\n › " + rinku + " upsname: [text]"
					a += "\n › " + rinku + " upname: [text]"
					a += "\n › " + rinku + " upstatus: [text]"
					a += "\n › " + rinku + " setrespon: [text]"
					a += "\n › " + rinku + " msgkick: [text]"
					a += "\n › " + rinku + " msgout: [text]"
					a += "\n › " + rinku + " msglimit: [text]"
					a += "\n › " + rinku + " msgfresh: [text]"
					a += "\n › " + rinku + " msgclearbans: [text]"
					a += "\n › " + rinku + " msgsider: [text]"
					a += "\n › " + rinku + " squadron: [name]"
					a += "\n › " + rinku + " link: [Yourlink]"
					a += "\n › " + rinku + " logo: [emoji]"
					a += "\n › " + rinku + " midteam: [mid]"
					a += "\n › " + rinku + " say [text]"
					a += "\n › " + rinku + " check msg"
					a += "\n › " + rinku + " addowners [@]"
					a += "\n › " + rinku + " delowners [@]"
					a += "\n › " + rinku + " ownerlist"
					a += "\n › " + rinku + " clearowners"
					a += "\n › " + rinku + " delowners [no]"
					a += "\n › " + rinku + " addstaff [@]"
					a += "\n › " + rinku + " delstaff [@]"
					a += "\n › " + rinku + " staff add"
					a += "\n › " + rinku + " staff del"
					a += "\n › " + rinku + " stafflist"
					a += "\n › " + rinku + " clearstaff"
					a += "\n › " + rinku + " delstaff [no]"
					a += "\n › " + rinku + " addbots [@]"
					a += "\n › " + rinku + " delbots [@]"
					a += "\n › " + rinku + " bot add"
					a += "\n › " + rinku + " bot del"
					a += "\n › " + rinku + " botlist"
					a += "\n › " + rinku + " clearbots"
					a += "\n › " + rinku + " delbots [no]"
					a += "\n › " + rinku + " backuplist"
					a += "\n › " + rinku + " banlist" + CListban
					a += "\n › " + rinku + " cban" + CClearbans
					a += "\n › " + rinku + " delbans [no]"
					a += "\n › " + rinku + " add me"
					a += "\n › " + rinku + " addall owners"
					a += "\n › " + rinku + " addall bots"
					a += "\n › " + rinku + " friends" + CFriens
					a += "\n › " + rinku + " grade"
					a += "\n › " + rinku + " respon" + CRespon
					a += "\n › " + rinku + " runtime"
					a += "\n › " + rinku + " rechat "
					a += "\n › " + rinku + " clear temp "
					a += "\n › " + rinku + " clear war "
					a += "\n › " + rinku + " keymap "
					a += "\n › " + rinku + " unsend" + CUnsend
					a += "\n › " + rinku + " speed" + CSpeed
					a += "\n › " + rinku + " speed all"
					a += "\n › " + rinku + " setbot" + CSet
					a += "\n › " + rinku + " cek" + CStatus
					a += "\n › " + rinku + " status account"
					a += "\n › " + rinku + " kickban"
					a += "\n › " + rinku + " kickcount"
					a += "\n › " + rinku + " batas [value]"
					a += "\n › " + rinku + " killmode on/off"
					a += "\n › " + rinku + " hardmode on/off"
					a += "\n › " + rinku + " autoclearbans on/off"
					a += "\n › " + rinku + " autopurge on/off"
					a += "\n › " + rinku + " forceqr on/off"
					a += "\n › " + rinku + " forceinv on/off"
					a += "\n › " + rinku + " forceajs on/off"
					a += "\n › " + rinku + " sider on/off"
					a += "\n\n  -- 𝗚𝗿𝗼𝘂𝗽 𝗚𝘂𝗶𝗱𝗲 --\n"
					a += "\n › " + rinku + " tagall"
					a += "\n › " + rinku + " groups" + CGroups
					a += "\n › " + rinku + " openqr [no]"
					a += "\n › " + rinku + " invited [no]"
					a += "\n › " + rinku + " bye [no]"
					a += "\n › " + rinku + " nukeall [no]"
					a += "\n › " + rinku + " leave all"
					a += "\n › " + rinku + " leave" + CLeave
					a += "\n › " + rinku + " kickall"
					a += "\n › " + rinku + " cancelall"
					a += "\n › " + rinku + " bypass"
					a += "\n › " + rinku + " inv squad" + CJoinall
					a += "\n › " + rinku + " kick [@] |" + CKick + " [@]"
					a += "\n › " + rinku + " nk [name]"
					a += "\n\n  -- 𝗣𝗿𝗼𝘁𝗲𝗰𝘁𝗶𝗼𝗻 --\n"
					a += "\n › " + rinku + " locknamegc on/off"
					a += "\n › " + rinku + " blockkick on/off"
					a += "\n › " + rinku + " blockqr on/off"
					a += "\n › " + rinku + " blockcancel on/off"
					a += "\n › " + rinku + " blockinvite on/off"
					a += "\n › " + rinku + " promax on/off"
					a += "\n › " + rinku + " list pro"
					a += "\n › " + rinku + " clear pro"
					a += "\n\n  -- 𝗔𝗻𝘁𝗶𝗷𝘀 𝗚𝘂𝗶𝗱𝗲 --\n"
					a += "\n › " + rinku + " addajs [@]"
					a += "\n › " + rinku + " clearajs"
					a += "\n › " + rinku + " ajslist"
					a += "\n › " + rinku + " ajs stay"
					a += "\n › " + rinku + " check ajs"
					a += "\n\n  -- 𝗦𝗲𝗹𝗳 𝗠𝗼𝗱𝗲 --\n"
					a += "\n › " + sname + " setleads [@]"
					a += "\n › " + sname + " getban"
					a += "\n › " + sname + " joinall" + CJoinall
					a += "\n › " + sname + " out [cmd main]"
					a += "\n › " + sname + " outall [cmd asist]"
					a += "\n › " + sname + " bots | here"
					a += "\n › " + rname + " value 1 > 10"
					a += "\n\n  -- 𝗨𝗽𝗱𝗮𝘁𝗲 𝗖𝗠𝗗 --\n"
					a += "\n › " + sname + " upcom [cmd] [newcmd]"
					a += "\n › " + rinku + " upsticker [cmd]"
					a += "\n › " + rinku + " [cmd] .silent"
					a += "\n\n  -- 𝗦𝗲𝘁𝗸𝗲𝘆 --\n"
					a += "\nSname: " + sname
					a += "\nRname: " + rname
					a += "\n\n𝗠𝘂𝗹𝘁𝗶 𝗰𝗼𝗺𝗺𝗮𝗻𝗱: " + sname + " [cmd],[cmd]"
					a += "\n\n@𝗠𝗲𝗻𝘁𝗶𝗼𝗻: [cmd]"
					a += "\n𝗥𝗲𝗽𝗹𝘆: [cmd]"
					a += "\n\n𝗦𝗾𝘂𝗮𝗱𝗿𝗼𝗻: " + NameTeam
					Tcm = append(Tcm, a)
				} else if strings.HasPrefix(txt, "upsticker ") {
					haniku := strings.ReplaceAll(txt, "upsticker ", "")
					ChangeStk = true
					HelpStk = haniku
					Tcm = append(Tcm, "Send sticker")
				} else if strings.HasPrefix(txt, "upcom ") {
					haniku := strings.ReplaceAll(txt, "upcom ", "")
					commandVH := strings.Split(haniku, " ")
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						if commandVH[0] == "help" {
							data.Coms.Help = commandVH[1]
						}
						if commandVH[0] == "respon" {
							data.Coms.Respon = commandVH[1]
						}
						if commandVH[0] == "listban" {
							data.Coms.Listban = commandVH[1]
						}
						if commandVH[0] == "clearbans" {
							data.Coms.Clearbans = commandVH[1]
						}
						if commandVH[0] == "leave" {
							data.Coms.Leave = commandVH[1]
						}
						if commandVH[0] == "speed" {
							data.Coms.Speed = commandVH[1]
						}
						if commandVH[0] == "status" {
							data.Coms.Status = commandVH[1]
						}
						if commandVH[0] == "friends" {
							data.Coms.Friens = commandVH[1]
						}
						if commandVH[0] == "groups" {
							data.Coms.Groups = commandVH[1]
						}
						if commandVH[0] == "invsquad" {
							data.Coms.Invsquad = commandVH[1]
						}
						if commandVH[0] == "kick" {
							data.Coms.Kick = commandVH[1]
						}
						if commandVH[0] == "set" {
							data.Coms.Set = commandVH[1]
						}
						if commandVH[0] == "joinall" {
							data.Coms.Joinall = commandVH[1]
						}
						if commandVH[0] == "unsend" {
							data.Coms.Unsend = commandVH[1]
						}
						if commandVH[0] == "out" {
							data.Coms.Out = commandVH[1]
						}
						if commandVH[0] == "outall" {
							data.Coms.Outall = commandVH[1]
						}
						if commandVH[0] == "kickban" {
							data.Coms.Kickban = commandVH[1]
						}
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						kowe := commandVH[0]
						jancuk := commandVH[1]
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+kowe+" > "+jancuk)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if txt == "goroutines" {
					nm := runtime.NumGoroutine()
					asc := fmt.Sprintf("%v", nm)
					Tcm = append(Tcm, asc)
				} else if txt == "/restart" || txt == "/reboot" {
					Tcm = append(Tcm, "Restarted")
					restart()
				} else if txt == "runtime" {
					elapsed := time.Since(startBots)
					rinku := fmtDuration(elapsed)
					Tcm = append(Tcm, rinku)
				} else if txt == "kickall" {
					runtime.GOMAXPROCS(4)
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					for _, v := range memlist {
						if !IsVhTeam(v.Mid) {
							fmt.Println(v.Mid)
							anjeng := v.Mid
							go func(anjeng string) {
								meyar.KickoutFromGroup(to, []string{anjeng})
							}(anjeng)
						}
					}
				} else if txt == "pending" {
					res, _ := meyar.GetGroup(to)
					memlist := res.Invitee
					a := "Pending list\n"
					for _, v := range memlist {
						if !IsVhTeam(v.Mid) {
							anjeng := v.Mid
							aso, _ := meyar.GetContact(anjeng)
							a += "\n  *" + aso.DisplayName
						}
					}
					Tcm = append(Tcm, a)
				} else if txt == "cancelall" {
					res, _ := meyar.GetGroup(to)
					memlist := res.Invitee
					for _, v := range memlist {
						if !IsVhTeam(v.Mid) {
							anjeng := v.Mid
							go func(anjeng string) {
								meyar.CancelGroupInvitation(to, []string{anjeng})
							}(anjeng)
						}
					}
				} else if txt == "bypass" {
					runtime.GOMAXPROCS(4)
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					memlist2 := res.Invitee
					for _, v := range memlist {
						if !IsVhTeam(v.Mid) {
							anjeng := v.Mid
							go func(anjeng string) {
								meyar.KickoutFromGroup(to, []string{anjeng})
							}(anjeng)
						}
					}
					for _, v := range memlist2 {
						if !IsVhTeam(v.Mid) {
							anjeng := v.Mid
							go func(anjeng string) {
								meyar.CancelGroupInvitation(to, []string{anjeng})
							}(anjeng)
						}
					}
				} else if strings.HasPrefix(txt, "nukeall ") {
					haniku := strings.ReplaceAll(txt, "nukeall ", "")
					ancok, _ := meyar.GetGroupIdsJoined()
					no, _ := strconv.Atoi(haniku)
					kura := ancok[no-1]
					runtime.GOMAXPROCS(4)
					res, _ := meyar.GetGroup(kura)
					memlist := res.Members
					memlist2 := res.Invitee
					for _, v := range memlist {
						if !IsVhTeam(v.Mid) {
							anjeng := v.Mid
							go func(anjeng string) {
								meyar.KickoutFromGroup(to, []string{anjeng})
							}(anjeng)
						}
					}
					for _, v := range memlist2 {
						if !IsVhTeam(v.Mid) {
							anjeng := v.Mid
							go func(anjeng string) {
								meyar.CancelGroupInvitation(to, []string{anjeng})
							}(anjeng)
						}
					}
					Tcm = append(Tcm, "SUCCESS")
				} else if txt == "here" || txt == "bots" {
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					var VHku = []string{}
					for _, v := range memlist {
						if IsBots(v.Mid) == true {
							VHku = append(VHku, v.Mid)
						}
					}
					anu := len(VHku) + 1
					anumu := len(VHsquad) + 1
					fmt.Println(anumu)
					Tcm = append(Tcm, "ʙᴏᴛ ɪɴ sǫᴜᴀᴅ: "+strconv.Itoa(anumu)+"\nʙᴏᴛs ɪɴ ɢʀᴏᴜᴘ: "+strconv.Itoa(anu))
				} else if txt == "getgroup name" {
					res, _ := meyar.GetGroup(to)
					namaGc := res.Name
					Tcm = append(Tcm, "ɴᴀᴍᴇ ɢʀᴏᴜᴘ: "+namaGc)
				} else if strings.HasPrefix(txt, "bring ") {
					haniku := strings.ReplaceAll(txt, "bring ", "")
					no, _ := strconv.Atoi(haniku)
					if VHleader == BotsMid {
						res, _ := meyar.GetGroup(to)
						res.PreventedJoinByTicket = false
						meyar.UpdateGroup(res)
						anum, _ := meyar.ReissueGroupTicket(res.ID)
						gTicket := "https://line.me/R/ti/g/" + anum
						for num, abots := range VHsquad {
							num++
							meyar.SendMessage(abots, gTicket, map[string]string{})
							if num >= no {
								break
							}
						}
						time.Sleep(time.Second * 1)
						res.PreventedJoinByTicket = true
						meyar.UpdateGroup(res)
					} else {
						Tcm = append(Tcm, "Not have leads")
					}
				} else if strings.HasPrefix(txt, "delowners ") {
					haniku := strings.ReplaceAll(txt, "delowners ", "")
					if VHleader == BotsMid {
						no, _ := strconv.Atoi(haniku)
						kura := VHowner[no-1]
						fmt.Println(kura)
						DeleteOwnerV2(kura)
						asuk, _ := meyar.GetContact(kura)
						Tcm = append(Tcm, "ᴅᴏɴ ᴅᴇʟᴇᴛᴇ: "+asuk.DisplayName)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "delbans ") {
					haniku := strings.ReplaceAll(txt, "delbans ", "")
					if VHleader == BotsMid {
						no, _ := strconv.Atoi(haniku)
						kura := VHblacklist[no-1]
						fmt.Println(kura)
						DeleteBlacklistV2(kura)
						asuk, _ := meyar.GetContact(kura)
						Tcm = append(Tcm, "ᴅᴏɴ ᴅᴇʟᴇᴛᴇ: "+asuk.DisplayName)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "delstaff ") {
					haniku := strings.ReplaceAll(txt, "delstaff ", "")
					if VHleader == BotsMid {
						no, _ := strconv.Atoi(haniku)
						kura := VHstaff[no-1]
						fmt.Println(kura)
						DeleteStaffV2(kura)
						asuk, _ := meyar.GetContact(kura)
						Tcm = append(Tcm, "ᴅᴏɴ ᴅᴇʟᴇᴛᴇ: "+asuk.DisplayName)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "delbots ") {
					haniku := strings.ReplaceAll(txt, "delbots ", "")
					if VHleader == BotsMid {
						no, _ := strconv.Atoi(haniku)
						kura := VHsquad[no-1]
						fmt.Println(kura)
						DeleteBotsV2(kura)
						asuk, _ := meyar.GetContact(kura)
						Tcm = append(Tcm, "ᴅᴏɴ ᴅᴇʟᴇᴛᴇ: "+asuk.DisplayName)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "openqr ") {
					haniku := strings.ReplaceAll(txt, "openqr ", "")
					ancok, _ := meyar.GetGroupIdsJoined()
					no, _ := strconv.Atoi(haniku)
					kura := ancok[no-1]
					fmt.Println(kura)
					res, _ := meyar.GetGroup(kura)
					res.PreventedJoinByTicket = false
					meyar.UpdateGroup(res)
					anum, _ := meyar.ReissueGroupTicket(res.ID)
					gTicket := "https://line.me/R/ti/g/" + anum
					Tcm = append(Tcm, gTicket)
				} else if strings.HasPrefix(txt, "invited ") {
					haniku := strings.ReplaceAll(txt, "invited ", "")
					ancok, _ := meyar.GetGroupIdsJoined()
					no, _ := strconv.Atoi(haniku)
					kura := ancok[no-1]
					meyar.FindAndAddContactsByMid(sender)
					meyar.InviteIntoGroup(kura, []string{sender})
					res, _ := meyar.GetGroup(kura)
					namaGc := res.Name
					gTicket := "ᴅᴏɴᴇ ɪɴᴠɪᴛᴇ ɪɴ " + namaGc
					Tcm = append(Tcm, gTicket)
				} else if strings.HasPrefix(txt, "bye ") {
					haniku := strings.ReplaceAll(txt, "bye ", "")
					ancok, _ := meyar.GetGroupIdsJoined()
					no, _ := strconv.Atoi(haniku)
					kura := ancok[no-1]
					meyar.LeaveGroup(kura)
					res, _ := meyar.GetGroup(kura)
					namaGc := res.Name
					gTicket := "ᴅᴏɴᴇ ʟᴇᴀᴠᴇ ɪɴ " + namaGc
					Tcm = append(Tcm, gTicket)
				} else if txt == "joinall" || txt == SJoinall || txt == CJoinall {
					if VHleader == BotsMid {
						JoinQr(to)
					} else {
						Tcm = append(Tcm, "ɴᴏᴛ ʜᴀᴠᴇ ʟᴇᴀᴅs")
					}
				} else if txt == "gname" {
					res, _ := meyar.GetGroup(to)
					namaGc := res.Name
					if len(namaGc) >= 50 {
						groupName := namaGc[0:50]
						asu := len(namaGc)
						meyar.SendMessage(to, string(asu), map[string]string{})
						meyar.SendMessage(to, string(groupName), map[string]string{})
					}
				} else if txt == "speed profile" {
					start := time.Now()
					meyar.GetProfile()
					elapsed := time.Since(start)
					stringTime := elapsed.String()
					Tcm = append(Tcm, stringTime[0:4]+" ms")
				} else if txt == "cek gc" {
					res, _ := meyar.GetCompactGroup(to)
					memlist := res.Members
					var LosDol = 0
					for _, v := range memlist {
						assw := v.Mid
						if IsBlacklist(assw) == true {
							go func(assw string) {
								fmt.Println(assw)
							}(assw)
							LosDol = LosDol + 1
							if LosDol >= 3 {
								LosDol = 0
								fmt.Println("ini break")
								break
							}
						}
					}
					for _, vz := range memlist {
						Lope := vz.Mid
						if IsBots(Lope) == true {
							NotInvited = append(NotInvited, Lope)
						}
					}
					for _, Midel := range VHsquad {
						if IsNotInv(Midel) == false {
							NeededInvited = append(NeededInvited, Midel)
						}
					}
					fmt.Println(NotInvited)
					fmt.Println(NeededInvited)
					NotInvited = []string{}
					NeededInvited = []string{}
				} else if txt == "speedbl" {
					start := time.Now()
					if !IsVhTeam(sender) {
						meyar.SendMessage("u1d092a84c7a415ede2c3f2c896769acb", "cok", map[string]string{})
						elapsed := time.Since(start)
						stringTime := elapsed.String()
						Tcm = append(Tcm, stringTime[0:4]+" ms")
					}
				} else if txt == "speed all" {
					start := time.Now()
					meyar.SendMessage("u0544cc8501324324fb7f35d334881c5c", "cok", map[string]string{})
					elapsed := time.Since(start)
					stringTime := elapsed.String()
					start1 := time.Now()
					meyar.CancelGroupInvitation(to, []string{"u1d092a84c7a415ede2c3f2c896769acb"})
					elapsed1 := time.Since(start1)
					stringTime1 := elapsed1.String()
					start2 := time.Now()
					meyar.InviteIntoGroup(to, []string{"u1d092a84c7a415ede2c3f2c896769acb"})
					elapsed2 := time.Since(start2)
					stringTime2 := elapsed2.String()
					start3 := time.Now()
					meyar.KickoutFromGroup(to, []string{"u1d092a84c7a415ede2c3f2c896769acb"})
					elapsed3 := time.Since(start3)
					stringTime3 := elapsed3.String()
					a := "Speed all:\n"
					a += "\nMessage: " + stringTime[0:4] + " ms"
					a += "\nCancel: " + stringTime1[0:4] + " ms"
					a += "\nInvite: " + stringTime2[0:4] + " ms"
					a += "\nKick: " + stringTime3[0:4] + " ms"
					Tcm = append(Tcm, a)
				} else if txt == "add me" {
					meyar.FindAndAddContactsByMid(sender)
					meyar.SendMention(msg.ID, to, "Success add @!", []string{sender}, "  SELFTCR™ 2022©", "https://s20.directupload.net/images/220423/uxdxnp5a.jpg", VHlink())
				} else if txt == "addall owners" {
					meyar.SendMessage(to, "ᴡᴀɪᴛ ғᴏʀ ᴀ ᴍɪɴᴜᴛᴇ ғᴏʀ ᴀᴅᴅ", map[string]string{})
					go func() {
						time.Sleep(time.Second * 3)
						if len(VHowner) != 0 {
							for _, ve := range VHowner {
								if IsFriends(ve) == false {
									time.Sleep(time.Second * 60)
									_, err := meyar.FindAndAddContactsByMid(ve)
									if err != nil {
										fmt.Println(err)
										break
									}
								}
							}
							meyar.SendMessage(to, "ᴅᴏɴᴇ ᴀᴅᴅ ᴀʟʟ ᴏᴡɴᴇʀ", map[string]string{})
						}
					}()

				} else if txt == "addall bots" {
					go func() {
						if len(VHsquad) != 0 {
							for _, ve := range VHsquad {
								if IsFriends(ve) == false {
									time.Sleep(time.Second * 80)
									_, err := meyar.FindAndAddContactsByMid(ve)
									if err != nil {
										fmt.Println(err)
										break
									}
								}
							}
							meyar.SendMessage(to, "ᴅᴏɴᴇ ᴀᴅᴅ ᴀʟʟ ʙᴏᴛs", map[string]string{})
						}
					}()
					meyar.SendMessage(to, "ᴡᴀɪᴛ ғᴏʀ ᴀ ᴍɪɴᴜᴛᴇ ғᴏʀ ᴀᴅᴅ", map[string]string{})
				} else if txt == "me" {
					meyar.SendContact(to, sender)
				} else if txt == "check msg" {
					vez := "𝗟𝗶𝘀?? 𝗺𝗲𝘀𝘀𝗮𝗴𝗲:"
					vez += "\n\n   Msg respon: " + setting.Responbot
					vez += "\n\n   Msg kick: " + setting.Msgkick
					vez += "\n\n   Msg out: " + setting.Msgout
					vez += "\n\n   Msg limit: " + setting.Msglimit
					vez += "\n\n   Msg fresh: " + setting.Msgfresh
					vez += "\n\n   Msg clearbans: " + setting.Msgclearbans
					vez += "\n\n   Msg sider: " + setting.Msgsider
					vez += "\n\n   Title: " + setting.Title
					vez += "\n\n   Link: " + setting.Linkicon
					vez += "\n\n   Logo: " + setting.Logo
					vez += "\n\n   Team: " + setting.Midteam
					Tcm = append(Tcm, vez)
				} else if strings.HasPrefix(txt, "joinqr: ") {
					su := "joinqr:"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					noodles := strings.Split(VezaGans, "|")
					fmt.Println(noodles)
					fmt.Println(noodles[0])
					fmt.Println(noodles[1])
					err := meyar.AcceptGroupInvitationByTicket(noodles[0], noodles[1])
					if err != nil {
						fmt.Println(err)
					}
					Tcm = append(Tcm, "cok")
				} else if strings.HasPrefix(txt, "join: ") {
					su := "join:"
					groups := AddedText(msg.Text, su, sname, rname)
					err := meyar.AcceptGroupInvitation(groups)
					if err != nil {
						fmt.Println(err)
					}
					Tcm = append(Tcm, "cok")
				} else if strings.HasPrefix(txt, "upname: ") {
					su := "upname:"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					profile_B, _ := meyar.GetProfile()
					profile_B.DisplayName = VezaGans
					meyar.UpdateProfileAttribute(2, profile_B.DisplayName)
					meyar.SendReply(msg.ID, to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
				} else if txt == "autoname" || txt == "auto name" {
					if VHleader == BotsMid {
						asu, _ := meyar.GetContact(VHleader)
						VezaGans := asu.DisplayName
						profile_B, _ := meyar.GetProfile()
						Newname := VezaGans + "(𝗺𝗮𝗶𝗻)"
						profile_B.DisplayName = Newname
						meyar.UpdateProfileAttribute(2, profile_B.DisplayName)
						meyar.SendReply(msg.ID, to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
					} else {
						if TimeDown(PosisiAsist) == true {
							asu, _ := meyar.GetContact(VHleader)
							VezaGans := asu.DisplayName
							haniku := strings.ReplaceAll(VezaGans, "(𝗺𝗮𝗶𝗻)", "")
							Newname := haniku + "(" + strconv.Itoa(PosisiAsist) + ")"
							profile_B, _ := meyar.GetProfile()
							profile_B.DisplayName = Newname
							meyar.UpdateProfileAttribute(2, profile_B.DisplayName)
							meyar.SendReply(msg.ID, to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+Newname, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
						}
					}
				} else if strings.HasPrefix(txt, "upstatus: ") {
					su := "upstatus:"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					profile_B, _ := meyar.GetProfile()
					profile_B.StatusMessage = VezaGans
					meyar.UpdateProfileAttribute(16, profile_B.StatusMessage)
					VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
				} else if strings.HasPrefix(txt, "setrespon: ") {
					su := "setrespon:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Responbot = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "uprname: ") {
					haniku := strings.ReplaceAll(txt, "uprname: ", "")
					rname = haniku
					meyar.SendMessage(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+haniku, map[string]string{})
				} else if strings.HasPrefix(txt, "say ") {
					su := "say"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					if TimeDown(PosisiAsist) == true {
						meyar.SendMessage(to, VezaGans, map[string]string{})
					}
				} else if strings.HasPrefix(txt, "upsname: ") {
					filename := VHBOTS
					if VHleader == BotsMid {
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						haniku := strings.ReplaceAll(txt, "upsname: ", "")
						data.Sname = haniku
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						meyar.SendMessage(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+haniku, map[string]string{})
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "msgkick: ") {
					su := "msgkick:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Msgkick = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "msgout: ") {
					su := "msgout:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Msgout = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "msglimit: ") {
					su := "msglimit:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Msglimit = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "msgfresh: ") {
					su := "msgfresh:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Msgfresh = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "link: ") {
					su := "link:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Linkicon = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "squadron: ") {
					su := "squadron:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Title = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "logo: ") {
					su := "logo:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Logo = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "midteam: ") {
					su := "midteam:"
					if VHleader == BotsMid {
						VezaGans := AddedText(msg.Text, su, sname, rname)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.Midteam = VezaGans
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
						VHSendText(to, "Success changed teams: "+VezaGans)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "msgsider: ") {
					su := "msgsider:"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					if strings.Contains(VezaGans, "%v") {
						if VHleader == BotsMid {
							filename := VHBOTS
							file, _ := ioutil.ReadFile(filename)
							data := Settings{}
							json.Unmarshal(file, &data)
							data.Msgsider = VezaGans
							dataBytes, _ := json.MarshalIndent(data, "", " ")
							ioutil.WriteFile(filename, dataBytes, 0644)
							VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						VHSendText(to, "Please used %v value in sider\n\nExample: "+sname+" msgsiders: Come on dude %v")
					}
				} else if txt == "sider on" {
					sider[to] = []string{}
					siderV2[to] = true
					Tcm = append(Tcm, "sɪᴅᴇʀ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "sider off" {
					delete(sider, to)
					siderV2[to] = false
					Tcm = append(Tcm, "sɪᴅᴇʀ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if strings.HasPrefix(txt, "msgclearbans: ") {
					su := "msgclearbans:"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					if strings.Contains(VezaGans, "%v") {
						if VHleader == BotsMid {
							filename := VHBOTS
							file, _ := ioutil.ReadFile(filename)
							data := Settings{}
							json.Unmarshal(file, &data)
							data.Msgclearbans = VezaGans
							dataBytes, _ := json.MarshalIndent(data, "", " ")
							ioutil.WriteFile(filename, dataBytes, 0644)
							VHSendText(to, "ᴅᴏɴᴇ ᴄʜᴀɴɢᴇ: "+VezaGans)
						} else {
							if TimeDown(PosisiAsist) == true {
								BackupVH()
							}
						}
					} else {
						VHSendText(to, "Please used %v value in blacklist\n\nExample: "+sname+" msgclearbans: Remove a %v Blacklist")
					}
				} else if txt == "autopurge off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoPurge = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					PurgeV2 = false
					Tcm = append(Tcm, "ᴀᴜᴛᴏ ᴘᴜʀɢᴇ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "autopurge on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoPurge = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					PurgeV2 = true
					Tcm = append(Tcm, "ᴀᴜᴛᴏ ᴘᴜʀɢᴇ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "autoclearbans on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoUnbaned = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					AutoClearbans = true
					Tcm = append(Tcm, "ᴀᴜᴛᴏ ᴄʟᴇᴀʀʙᴀɴs sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "autoclearbans off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoUnbaned = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					AutoClearbans = false
					Tcm = append(Tcm, "ᴀᴜᴛᴏ ᴄʟᴇᴀʀʙᴀɴs sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "forceqr on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoForceQr = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					ForceQr = true
					Tcm = append(Tcm, "ғᴏʀᴄᴇ ǫʀ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "forceqr off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoForceQr = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					ForceQr = false
					Tcm = append(Tcm, "ғᴏʀᴄᴇ ǫʀ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "forceajs on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoForceAjs = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					ForceAjs = true
					Tcm = append(Tcm, "ғᴏʀᴄᴇ ᴀᴊs sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "forceajs off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.AutoForceAjs = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					ForceAjs = false
					Tcm = append(Tcm, "ғᴏʀᴄᴇ ᴀᴊs sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "hardmode on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.VHhardMode = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					HardMode = true
					Tcm = append(Tcm, "ʜᴀʀᴅ ᴍᴏᴅᴇ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "hardmode off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.VHhardMode = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					HardMode = false
					Tcm = append(Tcm, "ʜᴀʀᴅ ᴍᴏᴅᴇ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "killmode on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.VHkillMode = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					KillMode = true
					Tcm = append(Tcm, "ᴋɪʟʟ ᴍᴏᴅᴇ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "killmode off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.VHkillMode = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					KillMode = false
					Tcm = append(Tcm, "ᴋɪʟʟ ᴍᴏᴅᴇ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "locknamegc on" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.LockNameGc = true
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					LockGC = true
					Tcm = append(Tcm, "ʟᴏᴄᴋ ɢʀᴏᴜᴘ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "locknamegc off" {
					if VHleader == BotsMid {
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.LockNameGc = false
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					LockGC = false
					Tcm = append(Tcm, "ʟᴏᴄᴋ ɢʀᴏᴜᴘ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "bot add" {
					VHAddbots = true
					Tcm = append(Tcm, "sᴇɴᴅ ᴀ ᴄᴏɴᴛᴀᴄᴛ ʙʀᴏ")
				} else if txt == "bot del" {
					VHDelbots = true
					Tcm = append(Tcm, "sᴇɴᴅ ᴀ ᴄᴏɴᴛᴀᴄᴛ ʙʀᴏ")
				} else if txt == "staff add" {
					VHAddstaff = true
					Tcm = append(Tcm, "sᴇɴᴅ ᴀ ᴄᴏɴᴛᴀᴄᴛ ʙʀᴏ")
				} else if txt == "staff del" {
					VHDelstaff = true
					Tcm = append(Tcm, "sᴇɴᴅ ᴀ ᴄᴏɴᴛᴀᴄᴛ ʙʀᴏ")
				} else if txt == "forceinv on" {
					ForceInv = true
					Tcm = append(Tcm, "ғᴏʀᴄᴇ ɪɴᴠ sᴇᴛ ᴛᴏ ᴏɴ")
				} else if txt == "forceinv off" {
					ForceInv = false
					Tcm = append(Tcm, "ғᴏʀᴄᴇ ɪɴᴠ sᴇᴛ ᴛᴏ ᴏғғ")
				} else if txt == "updatepict" {
					Changepic = true
					meyar.SendMessage(to, "sᴇɴᴅ ᴀ ᴘɪᴄᴛ ʙʀᴏ", map[string]string{})
				} else if txt == "updatevideo" {
					Changevp = true
					Tcm = append(Tcm, "sᴇɴᴅ ᴀ ᴠɪᴅᴇᴏ ʙʀᴏ")
				} else if txt == "updatecover" {
					Changecover = true
					Tcm = append(Tcm, "sᴇɴᴅ ᴀ ᴘɪᴄᴛ ʙʀᴏ")
				} else if strings.HasPrefix(txt, "addbl ") {
					asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
					kvs := asw
					for _, v := range kvs {
						if v != BotsMid {
							AddedBlacklist(v)
						}
					}
					Tcm = append(Tcm, "Success")
				} else if strings.HasPrefix(txt, "setleads ") || strings.HasPrefix(txt, "setinduk ") {
					if VHleader == "" {
						sep := strings.Split(txt, " ")
						texts := strings.Replace(txt, sep[0]+" "+sep[1]+" ", "", -1)
						fmt.Println("ini textnya " + texts)
						fmt.Println(msg.ContentMetadata["MENTION"])
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						cok := strings.Join(asw, " ")
						VHleader = cok
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴀᴅᴅ ᴛᴏ ʙᴇ ᴀ ʟᴇᴀᴅᴇʀ")
					} else {
						Tcm = append(Tcm, "ʜᴀᴠᴇ ʟᴇᴀᴅᴇʀ ᴄʟᴇᴀʀ ᴜɴᴅ ᴀᴅᴅ ᴀɢᴀɪɴ")
					}
				} else if strings.HasPrefix(txt, "batas ") {
					haniku := strings.ReplaceAll(txt, "batas ", "")
					if VHleader == BotsMid {
						no, _ := strconv.Atoi(haniku)
						filename := VHBOTS
						file, _ := ioutil.ReadFile(filename)
						data := Settings{}
						json.Unmarshal(file, &data)
						data.BatasVH = no
						VHbatas = no
						dataBytes, _ := json.MarshalIndent(data, "", " ")
						ioutil.WriteFile(filename, dataBytes, 0644)
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
					Vendi := fmt.Sprintf("%v", VHbatas)
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					for _, v := range memlist {
						if v.Mid == VHleader {
							VHAssistMessage(to, "Excute > Success to set "+Vendi)
							Warbots = true
						}
					}
					Tcm = append(Tcm, "Excute > Success to set "+Vendi)
					if VHleader == "" {
						Warbots = true
					}
				} else if strings.HasPrefix(txt, "value ") {
					haniku := strings.ReplaceAll(txt, "value ", "")
					no, _ := strconv.Atoi(haniku)
					PosisiAsist = no
					meyar.SendMessage(to, "Saved data", map[string]string{})
				} else if txt == "clearleads" || txt == "clearinduk" {
					VHleader = ""
					meyar.SendMessage(to, "Saved data", map[string]string{})
				} else if txt == "cek token" || txt == "token" {
					meyar.SendMessage(to, service.AuthToken, map[string]string{})
				} else if txt == "friends" || txt == SFriens || txt == CFriens {
					a := "----- 𝗟𝗶𝘀𝘁 𝗙𝗿𝗶𝗲𝗻𝗱 -----\n"
					ancok, _ := meyar.GetAllContactIds()
					for jaran, cok := range ancok {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						asu, _ := meyar.GetContact(cok)
						a += "\n* " + VezaGanteng + ". " + asu.DisplayName
						fmt.Println(asu.DisplayName)
					}
					a += "\n\n𝗨𝘀𝗲𝗱: \n  " + sname + " / " + rname + " addall bots"
					anu := PosisiAsist
					if TimeDown(anu) == true {
						meyar.SendMessage(to, a, map[string]string{})
					} else {
						meyar.SendMessage(to, a, map[string]string{})
					}
				} else if txt == "list protect" || txt == "listprotect" || txt == "list pro" {
					a := lgo + "---- ʟɪsᴛ ᴘʀᴏᴛᴇᴄᴛ ----" + lgo + "\n"
					ancok, _ := meyar.GetGroupIdsJoined()
					for jaran, cok := range ancok {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						asu, _ := meyar.GetGroup(cok)
						a += "\n" + VezaGanteng + ". " + asu.Name
						if IsBlockqr(cok) == true {
							a += "\n    ✅ ʙʟᴏᴄᴋǫʀ"
						} else {
							a += "\n    ❌   ʙʟᴏᴄᴋǫʀ"
						}
						if IsBlockkick(cok) == true {
							a += "\n    ✅ ʙʟᴏᴋᴋɪᴄᴋ"
						} else {
							a += "\n    ❌   ʙʟᴏᴋᴋɪᴄᴋ"
						}
						if IsBlockinvite(cok) == true {
							a += "\n    ✅ ʙʟᴏᴄᴋɪɴᴠɪᴛᴇ"
						} else {
							a += "\n    ❌   ʙʟᴏᴄᴋɪɴᴠɪᴛᴇ"
						}
						if IsBlockcancel(cok) == true {
							a += "\n    ✅ ʙʟᴏᴄᴋᴄᴀɴᴄᴇʟ"
						} else {
							a += "\n    ❌   ʙʟᴏᴄᴋᴄᴀɴᴄᴇʟ"
						}
					}
					a += "\n\n𝗦𝗾𝘂𝗮𝗱𝗿𝗼𝗻: " + NameTeam
					Tcm = append(Tcm, a)
				} else if txt == "groups" || txt == SGroups || txt == CGroups {
					a := "----- 𝗟𝗶𝘀𝘁 𝗚𝗿𝗼𝘂𝗽s -----\n"
					ancok, _ := meyar.GetGroupIdsJoined()
					for jaran, cok := range ancok {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						asu, _ := meyar.GetGroup(cok)
						a += "\n* " + VezaGanteng + ". " + asu.Name
					}
					a += "\n\n𝗨𝘀𝗲𝗱: \n  " + sname + " / " + rname + " groups"
					anu := PosisiAsist
					if TimeDown(anu) == true {
						meyar.SendMessage(to, a, map[string]string{})
					} else {
						meyar.SendMessage(to, a, map[string]string{})
					}
				} else if txt == "leave all" {
					ancok, _ := meyar.GetGroupIdsJoined()
					for jaran, cok := range ancok {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						if cok != to {
							meyar.LeaveGroup(cok)
							fmt.Println(VezaGanteng)
						}
					}
					Tcm = append(Tcm, "ᴅᴏɴᴛ ʟᴇᴀᴠᴇ ᴀʟʟ ɢʀᴏᴜᴘ")
				} else if txt == "backuplist" {
					if len(VHbackup) != 0 {
						a := lgo + "----- List Backup -----" + lgo + "\n"
						for jaran, cok := range VHbackup {
							jaran++
							VezaGanteng := strconv.Itoa(jaran)
							asu, _ := meyar.GetContact(cok)
							a += "\n* " + VezaGanteng + ". @!"
							fmt.Println(asu.DisplayName)
						}
						a += "\n\nAmount: " + strconv.Itoa(len(VHbackup)) + " Backup"
						if TimeDown(PosisiAsist) == true {
							meyar.SendMention(msg.ID, to, a, VHbackup, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
						}
					} else {
						Tcm = append(Tcm, "ɴᴏᴛ ʜᴀᴠᴇ ʙᴏᴛs ɪɴ ʟɪsᴛ")
					}
				} else if txt == "botlist" {
					if len(VHsquad) != 0 {
						a := lgo + "----- List Bots -----" + lgo + "\n"
						for jaran, cok := range VHsquad {
							jaran++
							VezaGanteng := strconv.Itoa(jaran)
							asu, _ := meyar.GetContact(cok)
							a += "\n* " + VezaGanteng + ". @!"
							fmt.Println(asu.DisplayName)
						}
						a += "\n\nAmount: " + strconv.Itoa(len(VHsquad)) + " Squads"
						if TimeDown(PosisiAsist) == true {
							meyar.SendMention(msg.ID, to, a, VHsquad, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
						}

					} else {
						Tcm = append(Tcm, "ɴᴏᴛ ʜᴀᴠᴇ ʙᴏᴛs ɪɴ ʟɪsᴛ")
					}
				} else if txt == "ownerlist" {
					a := lgo + "---- 𝗟𝗶𝘀𝘁 𝗢𝘄𝗻𝗲𝗿𝘀 ----" + lgo + "\n"
					for jaran, cok := range VHowner {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						asu, _ := meyar.GetContact(cok)
						a += "\n* " + VezaGanteng + ". " + asu.DisplayName
						fmt.Println(asu.DisplayName)
					}
					a += "\n𝗨𝘀𝗲𝗱: \n    " + sname + " / " + rname + " clearowners \n    " + sname + " / " + rname + " addowners @\n    " + sname + " / " + rname + " delowners @\n    " + sname + " / " + rname + " delowners [no]"
					Tcm = append(Tcm, a)
				} else if txt == "stafflist" {
					a := lgo + "---- 𝗟𝗶𝘀𝘁 𝗦𝘁𝗮𝗳𝗳 ----" + lgo + "\n"
					for jaran, cok := range VHstaff {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						asu, _ := meyar.GetContact(cok)
						a += "\n* " + VezaGanteng + ". " + asu.DisplayName
						fmt.Println(asu.DisplayName)
					}
					a += "\n𝗨𝘀𝗲𝗱: \n    " + sname + " / " + rname + " clearstaff \n    " + sname + " / " + rname + " addstaff @\n    " + sname + " / " + rname + " delstaff @\n    " + sname + " / " + rname + " delstaff [no]"
					Tcm = append(Tcm, a)
				} else if strings.HasPrefix(txt, "addbots ") {
					asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
					kvs := asw
					for _, v := range kvs {
						if v != BotsMid {
							AddedBots(v)
						}
					}
					a := "----- List Bots -----\n"
					for jaran, cok := range VHsquad {
						jaran++
						VezaGanteng := strconv.Itoa(jaran)
						asu, _ := meyar.GetContact(cok)
						a += "\n* " + VezaGanteng + ". @!"
						fmt.Println(asu.DisplayName)
					}
					a += "\n\nAmount: " + strconv.Itoa(len(VHsquad)) + " Squads"
					res, _ := meyar.GetContact(sender)
					VHSendMention(msg.ID, to, a, VHsquad, "  "+res.DisplayName, "https://obs.line-apps.com/os/p/"+sender, VHlink())
				} else if txt == "ajslist" {
					if len(VHajs) != 0 {
						a := lgo + "---- List AJS ----" + lgo + "\n"
						for jaran, cok := range VHajs {
							jaran++
							VezaGanteng := strconv.Itoa(jaran)
							asu, _ := meyar.GetContact(cok)
							a += "\n* " + VezaGanteng + ". @!"
							fmt.Println(asu.DisplayName)
						}
						a += "\n\nAmount: " + strconv.Itoa(len(VHajs)) + " AntiJS"
						res, _ := meyar.GetContact(sender)
						VHSendMention(msg.ID, to, a, VHajs, "  "+res.DisplayName, "https://obs.line-apps.com/os/p/"+sender, VHlink())
					} else {
						Tcm = append(Tcm, "ᴅᴏɴᴛ ʜᴀᴠᴇ ᴀɴᴛɪ ᴀᴊs")
					}
				} else if strings.HasPrefix(txt, "addajs ") {
					if VHleader == BotsMid {
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						kvs := asw
						for _, v := range kvs {
							AddedAjs(v)
						}
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
						time.Sleep(time.Second * 2)
						if len(VHajs) != 0 {
							if IsAjs(BotsMid) == true {
								meyar.LeaveGroup(to)
							} else {
								Tcm = append(Tcm, "ᴅᴏɴᴇ ᴀᴅᴅ ᴀᴊs sᴜᴄᴄᴇss")
							}
						}
					}
				} else if strings.HasPrefix(txt, "addowners ") {
					if VHleader == BotsMid {
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						kvs := asw
						for _, v := range kvs {
							AddedOwner(v)
						}
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴀᴅᴅ Owner sᴜᴄᴄᴇss")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "addstaff ") {
					if VHleader == BotsMid {
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						kvs := asw
						for _, v := range kvs {
							AddedStaff(v)
						}
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴀᴅᴅ sᴛᴀғғ sᴜᴄᴄᴇss")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "delowners ") {
					if VHleader == BotsMid {
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						kvs := asw
						for _, v := range kvs {
							DeleteOwnerV2(v)
						}
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴅᴇʟʟ Owner sᴜᴄᴄᴇss")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "delbots ") {
					if VHleader == BotsMid {
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						kvs := asw
						for _, v := range kvs {
							DeleteBotsV2(v)
						}
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴅᴇʟʟ ʙᴏᴛ sᴜᴄᴄᴇss")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "delstaff ") {
					if VHleader == BotsMid {
						asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
						kvs := asw
						for _, v := range kvs {
							DeleteStaffV2(v)
						}
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴅᴇʟʟ sᴛᴀғғ sᴜᴄᴄᴇss")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if strings.HasPrefix(txt, "kick ") || strings.HasPrefix(txt, CKick+" ") {
					sep := strings.Split(txt, " ")
					texts := strings.Replace(txt, sep[0]+" "+sep[1]+" ", "", -1)
					fmt.Println("ini textnya " + texts)
					fmt.Println(msg.ContentMetadata["MENTION"])
					asw := helper.GetMidFromMentionees(msg.ContentMetadata["MENTION"])
					if helper.InArray(asw, BotsMid) == false {
						if VHleader != "" {
							for _, v := range asw {
								go func(v string) {
									if IsMember(v, to) == true {
										if setting.Msgkick != "" {
											meyar.SendMention(msg.ID, to, setting.Msgkick+" @! ", []string{v}, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
										} else {
											meyar.SendMention(msg.ID, to, "ʙʏᴇ ʙʏᴇ ^~^ @! ", []string{v}, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
										}
										err := meyar.KickoutFromGroup(to, []string{v})
										if err != nil {
											fmt.Println(err)
											meyar.SendMessage(to, "sᴏʀʀʏ ɪ ʟɪᴍɪᴛ !!!", map[string]string{})
										} else if err == nil {
											if v != BotsMid {
												AddedBlacklist(v)
											}
										}
									}
								}(v)
							}
						} else {
							Tcm = append(Tcm, "Not have leads")
						}
					}
				} else if strings.HasPrefix(txt, "nk ") {
					su := "nk"
					VezaGans := AddedText(msg.Text, su, sname, rname)
					res, _ := meyar.GetGroup(to)
					memlist := res.Members
					cokz := []string{}
					for _, a := range memlist {
						if strings.Contains(a.DisplayName, VezaGans) {
							cokz = append(cokz, a.Mid)
						}
					}
					for _, v := range cokz {
						go func(v string) {
							meyar.KickoutFromGroup(to, []string{v})
						}(v)
						if v != BotsMid {
							AddedBlacklist(v)
						}
					}
				} else if txt == "clearowners" {
					if VHleader == BotsMid {
						DeleteOwner(sender)
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴄʟᴇᴀʀ ᴀʟʟ ᴏᴡɴᴇʀ")
					} else {
						if TimeDown(PosisiAsist) == true {
							DeleteOwner(sender)
						}
					}
				} else if txt == "clearstaff" {
					if VHleader == BotsMid {
						ClearStaff(sender)
						Tcm = append(Tcm, "ᴅᴏɴᴇ ᴄʟᴇᴀʀ ᴀʟʟ sᴛᴀғғ")
					} else {
						if TimeDown(PosisiAsist) == true {

							ClearStaff(sender)
						}
					}
				} else if txt == "fix" {
					if TimeDown(PosisiAsist) == true {
						BackupVH()
					}
					Tcm = append(Tcm, "ғɪxᴇᴅ ᴘʀᴏɢʀᴀᴍ")
				} else if txt == "clearajs" {
					if VHleader == BotsMid {
						res, _ := meyar.GetGroup(to)
						res.PreventedJoinByTicket = false
						meyar.UpdateGroup(res)
						anum, _ := meyar.ReissueGroupTicket(res.ID)
						gTicket := "https://line.me/R/ti/g/" + anum
						for _, a := range VHajs {
							VHSendText(a, gTicket)
						}
						time.Sleep(time.Second * 1)
						res.PreventedJoinByTicket = true
						meyar.UpdateGroup(res)
						Tcm = append(Tcm, "ᴅᴇʟᴇᴛᴇ ᴀᴊs sᴜᴄᴄᴇss")
						DeleteAjs()
					} else {
						if TimeDown(PosisiAsist) == true {
							DeleteAjs()
						}
						Tcm = append(Tcm, "ɴᴏᴛ ʜᴀᴠᴇ ʟᴇᴀᴅs")
					}
				} else if txt == "?appname" {
					meyar.SendFooter(msg.ID, to, string(config.LINE_APPLICATION), "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())

				} else if txt == "///hostname" {
					Tcm = append(Tcm, string(config.LINE_HOST_DOMAIN))
				} else if txt == "masa aktif" || txt == "duration" {
					if VHleader == BotsMid {
						response, err := http.Get("https://api.vhtear.com/Gocheckip=" + fmt.Sprintf("%v", helper.CheckIp()))
						if err != nil {
							fmt.Printf("%s", err)
						} else {
							defer response.Body.Close()
							body, err := ioutil.ReadAll(response.Body)
							if err != nil {
								fmt.Printf("%s", err)
							}
							cd := "Active period\n"
							cd += "\n* Ip_addr : " + gjson.Get(string(body), "result.ip_addr").String()
							cd += "\n* Name : " + gjson.Get(string(body), "result.nama").String()
							cd += "\n* From : " + gjson.Get(string(body), "result.from").String()
							cd += "\n* Expired : " + gjson.Get(string(body), "result.expired").String()
							cd += "\n* Status expired : " + gjson.Get(string(body), "result.apart").String()
							Tcm = append(Tcm, cd)
						}
					}
				} else if txt == "cek ip" {
					a := fmt.Sprintf("%v", helper.CheckIp())
					if TimeDown(PosisiAsist) == true {
						meyar.SendMessage(to, a, map[string]string{})
					} else {
						meyar.SendMessage(to, a, map[string]string{})
					}
				} else if txt == "clearbots" {
					Tcm = append(Tcm, "ᴅᴏɴᴇ ᴄʟᴇᴀʀ ᴀʟʟ ʙᴏᴛs")
					VHsquad = []string{}
				} else if txt == "inv squad" || txt == CInvsquad || txt == SInvsquad {
					err := meyar.InviteIntoGroup(to, VHsquad)
					if err != nil {
						Tcm = append(Tcm, "ʙᴇɪɴɢ sɪᴄᴋ ✘")
					}
					fmt.Println("Bagus")
				} else if txt == "ajs stay" || txt == "blockjs on" {
					if IsAjs(BotsMid) == true {
						meyar.LeaveGroup(to)
					} else {
						InvitedAjs(to)
					}
				} else if txt == "check ajs" || txt == "cek ajs" {
					res, _ := meyar.GetGroup(to)
					memlist := res.Invitee
					for _, v := range memlist {
						if IsAjs(v.Mid) {
							Tcm = append(Tcm, "ᴀɴᴛɪᴊs ʙᴇ ɪɴ ᴀ ɢʀᴏᴜᴘ ɪɴᴠɪᴛᴇᴅ")
						}
					}
				} else if txt == "keymap" || txt == "petunjuk" {
					anumumu := helper.Keymap
					Tcm = append(Tcm, anumumu)
				} else if txt == "rechat" || txt == "removechat" {
					ancok, _ := meyar.GetGroupIdsJoined()
					for _, cok := range ancok {
						meyar.RemoveAllMessages(cok)
					}
					Tcm = append(Tcm, "ʀᴇᴍᴏᴠᴇ ᴀʟʟ ᴍsɢ ✔️")
				} else if txt == "leave" || txt == SLeave {
					if TimeDown(PosisiAsist) == true {
						meyar.LeaveGroup(to)
					} else {
						meyar.LeaveGroup(to)
					}
				} else if txt == "outall" || txt == COutall {
					if VHleader != BotsMid {
						if TimeDown(PosisiAsist) == true {
							meyar.LeaveGroup(to)
						}
					}
				} else if txt == "out" || txt == COut {
					Warbots = false
					if VHleader == BotsMid {
						if setting.Msgout != "" {
							res, _ := meyar.GetGroup(to)
							VHSendMention(msg.ID, to, setting.Msgout+" @! ", []string{sender}, "ɢʀᴏᴜᴘ: "+res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
						} else {
							res, _ := meyar.GetGroup(to)
							VHSendMention(msg.ID, to, "ʙʏᴇ ʙʏᴇ @! ", []string{sender}, "ɢʀᴏᴜᴘ: "+res.Name, "https://obs.line-scdn.net/"+res.PictureStatus, VHlink())
						}
						meyar.LeaveGroup(to)
					}
				} else if txt == "kickcount" || txt == "count" {
					go func() {
						//var asss string
						Ki := fmt.Sprintf("\n    -ᴋɪᴄᴋ %v, -ɪɴᴠ %v, -ᴄᴀɴᴄᴇʟ %v", Ckick, Cinvite, Ccancel)
						Ks := fmt.Sprintf("%v", Ckick)
						Inv := fmt.Sprintf("%v", Cinvite)
						Can := fmt.Sprintf("%v", Ccancel)
						//asss = Ki + Inv + Can
						if VHleader != BotsMid {
							if TimeDown(PosisiAsist) == true {
								meyar.SendMessage(VHleader, "kicount"+Ks, map[string]string{})
								meyar.SendMessage(VHleader, "incount"+Inv, map[string]string{})
								meyar.SendMessage(VHleader, "cacount"+Can, map[string]string{})
								meyar.SendMessage(VHleader, "qwerty"+Ki, map[string]string{})
							}
						}
						time.Sleep(450 * time.Millisecond)
						cokk := "ᴡᴀʀ ʜɪsᴛᴛᴏʀʏ:\n\n  ᴍᴀɪɴ:" + Ki
						for no, bot := range StatusAsist {
							no++
							cokk += "\n  ʙᴏᴛ" + strconv.Itoa(no) + ": " + bot
						}
						cokk += "\n\nᴛᴏᴛᴀʟ:\n  ᴋɪᴄᴋ: " + strconv.Itoa(Akick+Ckick) + "\n  ɪɴᴠ: " + strconv.Itoa(Ainvite+Cinvite) + "\n  ᴄᴀɴᴄᴇʟ: " + strconv.Itoa(Acancel+Ccancel)
						if VHleader == BotsMid {
							meyar.SendMessage(to, cokk, map[string]string{})
							Akick = 0
							Ainvite = 0
							Acancel = 0
							StatusAsist = []string{}
						}
					}()
					if VHleader == "" {
						var asss string
						Ki := fmt.Sprintf("\n  -ᴋɪᴄᴋ: %v", Ckick)
						Inv := fmt.Sprintf("\n  -ɪɴᴠ: %v", Cinvite)
						Can := fmt.Sprintf("\n  -ᴄᴀɴᴄᴇʟ: %v", Ccancel)
						asss = Ki + Inv + Can
						cokk := "ᴡᴀʀ ʜɪsᴛᴏʀʏ:\nʙᴏᴛ:" + asss
						Tcm = append(Tcm, cokk)
					}
				} else if txt == "kickban" || txt == CKickban {
					go func() {
						var asss string
						ve := "u83e523fdd379d9f31a00dc4e8c4036f5"
						err := meyar.KickoutFromGroup(to, []string{ve})
						if err != nil {
							fmt.Println(err)
							if err, ok := err.(*LineThrift.TalkException); ok {
								fmt.Println(err.Reason)
								if err.Reason == err.Reason {
									if setting.Msglimit != "" {
										asss = setting.Msglimit
									} else {
										asss = "✘"
									}
									if VHleader != BotsMid {
										if TimeDown(PosisiAsist) == true {
											meyar.SendMessage(VHleader, "qwerty"+asss, map[string]string{})
										}
									}
								}
							}
						} else if err == nil {
							if setting.Msgfresh != "" {
								asss = setting.Msgfresh
							} else {
								asss = "✔️"
							}
							if VHleader != BotsMid {
								if TimeDown(PosisiAsist) == true {
									meyar.SendMessage(VHleader, "qwerty"+asss, map[string]string{})
								}
							}
						}
						time.Sleep(450 * time.Millisecond)
						cokk := "sᴛᴀᴛᴜs:\n   ᴍᴀɪɴ: " + asss
						for no, bot := range StatusAsist {
							no++
							cokk += "\n   ʙᴏᴛ" + strconv.Itoa(no) + ": " + bot
						}
						if VHleader == BotsMid {
							meyar.SendMessage(to, cokk, map[string]string{})
							StatusAsist = []string{}
						}
					}()
					if VHleader == "" {
						ve := "u0544cc8501324324fb7f35d334881c5c"
						err := meyar.InviteIntoGroup(to, []string{ve})
						if err != nil {
							fmt.Println(err)
							if err, ok := err.(*LineThrift.TalkException); ok {
								fmt.Println(err.Reason)
								if err.Reason == err.Reason {
									Tcm = append(Tcm, "ABUSE_BLOCK")
								}
							}
						} else if err == nil {
							Tcm = append(Tcm, "Very healthy* Hooray!")
						}
					}
				} else if txt == "cek" || txt == CStatus || txt == SStatus || txt == "getban" {
					go func() {
						var asss string
						ve := "u0544cc8501324324fb7f35d334881c5c"
						_, err := meyar.FindAndAddContactsByMid(ve)
						if err != nil {
							fmt.Println(err)
							if err, ok := err.(*LineThrift.TalkException); ok {
								fmt.Println(err.Reason)
								if err.Reason == err.Reason {
									if setting.Msglimit != "" {
										asss = setting.Msglimit
									} else {
										asss = "✘"
									}
									if VHleader != BotsMid {
										if TimeDown(PosisiAsist) == true {
											meyar.SendMessage(VHleader, "qwerty"+asss, map[string]string{})
										}
									}
								}
							}
						} else if err == nil {
							if setting.Msgfresh != "" {
								asss = setting.Msgfresh
							} else {
								asss = "✔️"
							}
							if VHleader != BotsMid {
								if TimeDown(PosisiAsist) == true {
									meyar.SendMessage(VHleader, "qwerty"+asss, map[string]string{})
								}
							}
						}
						time.Sleep(450 * time.Millisecond)
						cokk := "-- sᴛᴀᴛᴜs --\nᴍᴀɪɴ: " + asss
						for no, bot := range StatusAsist {
							no++
							cokk += "\nʙᴏᴛ" + strconv.Itoa(no) + ": " + bot
						}
						if VHleader == BotsMid {
							meyar.SendMessage(to, cokk, map[string]string{})
							StatusAsist = []string{}
						}
					}()
					if VHleader == "" {
						ve := "u0544cc8501324324fb7f35d334881c5c"
						_, err := meyar.FindAndAddContactsByMid(ve)
						if err != nil {
							fmt.Println(err)
							if err, ok := err.(*LineThrift.TalkException); ok {
								fmt.Println(err.Reason)
								if err.Reason == err.Reason {
									Tcm = append(Tcm, "ABUSE_BLOCK")
								}
							}
						} else if err == nil {
							Tcm = append(Tcm, "Very healthy* Hooray!")
						}
					}
				} else if txt == "speed2" || txt == SSpeed || txt == CSpeed {
					go func() {
						var asss string
						if TimeDown(PosisiAsist) == true {
							start := time.Now()
							asu := fmt.Sprintf("%v", start.Nanosecond())
							meyar.SendMessage(to, "ʀᴇᴄ ᴍᴏᴍᴇɴᴛs: "+asu[0:2], map[string]string{})
							elapsed := time.Since(start)
							stringTime := elapsed.String()
							asss = stringTime[0:4] + " ᴍs"
							if VHleader != BotsMid {
								meyar.SendMessage(VHleader, "speedku"+asss, map[string]string{})
							}
							time.Sleep(450 * time.Millisecond)
							//strs := strings.Join(StatusAsist, "\n  ◕ ")
							cokk := "ʙᴇɴᴄʜᴍᴀʀᴋ:\n  ᴍᴀɪɴ: " + asss
							for no, bot := range StatusAsist {
								no++
								cokk += "\n  ʙᴏᴛ" + strconv.Itoa(no) + ": " + bot
							}
							if VHleader == BotsMid {
								meyar.SendMessage(to, cokk, map[string]string{})
								StatusAsist = []string{}
							}
						}
					}()
					if VHleader == "" {
						start := time.Now()
						meyar.SendMessage("u1d092a84c7a415ede2c3f2c896769acb", ".", map[string]string{})
						elapsed := time.Since(start)
						aswq := elapsed.String()
						Tcm = append(Tcm, aswq[0:4]+" ᴍs")
					}
				} else if txt == "speed" || txt == SSpeed || txt == CSpeed {
					go func() {
						var asss string
						if TimeDown(PosisiAsist) == true {
							start := time.Now()
							meyar.SendMessage("u83e523fdd379d9f31a00dc4e8c4036f5", "ʀᴇᴄ ᴍᴏᴍᴇɴᴛs: ", map[string]string{})
							elapsed := time.Since(start)
							stringTime := elapsed.String()
							asu := fmt.Sprintf("%v", start.Nanosecond())
							meyar.SendMessage(to, "ʀᴇᴄ ᴍᴏᴍᴇɴᴛs: "+asu[0:2], map[string]string{})
							asss = stringTime[0:4] + " ᴍs"
							if VHleader != BotsMid {
								meyar.SendMessage(VHleader, "speedku"+asss, map[string]string{})
							}
							time.Sleep(450 * time.Millisecond)
							//strs := strings.Join(StatusAsist, "\n  ◕ ")
							cokk := "-- ꜱᴘᴇᴇᴅᴄᴇᴋ --\nᴍᴀɪɴ: " + asss
							for no, bot := range StatusAsist {
								no++
								cokk += "\nʙᴏᴛ" + strconv.Itoa(no) + ": " + bot
							}
							if VHleader == BotsMid {
								meyar.SendMessage(to, cokk, map[string]string{})
								StatusAsist = []string{}
							}
						}
					}()
					if VHleader == "" {
						start := time.Now()
						meyar.SendMessage("u1d092a84c7a415ede2c3f2c896769acb", ".", map[string]string{})
						elapsed := time.Since(start)
						aswq := elapsed.String()
						Tcm = append(Tcm, aswq[0:4]+" ms")
					}
				} else if txt == "clear protect" || txt == "clear pro" {
					if VHleader == BotsMid {
						file2, _ := ioutil.ReadFile(VHBOTS)
						data2 := Settings{}
						json.Unmarshal(file2, &data2)
						data2.VHProcancel = []string{}
						data2.VHProinvite = []string{}
						data2.VHProjoin = []string{}
						data2.VHProkick = []string{}
						data2.VHProqr = []string{}
						dataBytes2, _ := json.MarshalIndent(data2, "", " ")
						ioutil.WriteFile(VHBOTS, dataBytes2, 0644)
						proQr = []string{}
						VHblacklist = []string{}
						proQr = []string{}
						proKick = []string{}
						proInvite = []string{}
						proCancel = []string{}
						Tcm = append(Tcm, "sᴜᴄᴄᴇss ᴄʟᴇᴀʀ ᴘʀᴏᴛᴇᴄᴛ ɪɴ ᴀʟʟ ɢʀᴏᴜᴘ")
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				} else if txt == "unsend" || txt == SUnsend || txt == CUnsend {
					message, _ := meyar.GetRecentMessagesV2(to, 10001)
					MED := []string{}
					for _, i := range message {
						if i.ID != "" {
							if i.From_ == BotsMid {
								MED = append(MED, i.ID)
							}
						}
					}
					for _, itel := range MED {
						meyar.UnsendMessage(itel)
					}
				} else if txt == "tess" {
					LockURL(to)
				} else if strings.Contains(pesan, "/spam") {
					go func() {
						meyar.FindAndAddContactsByMid("u46b09bb376a7eedb39aebffd1863a050")
					}()
					for i := 1; i <= 1000; i++ {
						time.Sleep(time.Second * 5)
						meyar.CreateGroup("ᴛᴇsᴛ sᴘᴀᴍ ᴄᴏᴋ", VHowner)
					}
				} else if txt == "clear" || txt == "clear temp" {
					cmd := exec.Command("go", "fix")
					cmd.CombinedOutput()
					out, err := cmd.CombinedOutput()
					if err != nil {
						fmt.Println(err)
					}
					toket := string(out)
					fmt.Println(toket)
					Tcm = append(Tcm, "ᴄʟᴇᴀʀ ᴛᴇᴍᴘ ✔️")
				} else if txt == "clear war" {
					cmd := exec.Command("go", "clean")
					cmd1 := exec.Command("go", "fix")
					cmd1.CombinedOutput()
					out, err := cmd.CombinedOutput()
					if err != nil {
						fmt.Println(err)
					}
					toket := string(out)
					fmt.Println(toket)
					Tcm = append(Tcm, "ᴄʟᴇᴀʀ ᴡᴀʀ ✔️")
				}
			}
			if len(Tcm) != 0 {
				strs := strings.Join(Tcm, ",\n")
				fmt.Println(strs)
				if !silent {
					if strs != "" {
						if VHleader == BotsMid {
							meyar.SendFooter(msg.ID, to, strs, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
						} else {
							if VHleader == "" {
								meyar.SendFooter(msg.ID, to, strs, "  "+NameTeam, "https://obs.line-apps.com/os/p/"+sender, VHlink())
							}
						}
					}
				}
				Tcm = []string{}
			}
			if AutoClearbans == true {
				go func() {
					if len(VHblacklist) != 0 {
						time.Sleep(time.Second * 25)
						jaran := len(VHblacklist)
						asu := strconv.Itoa(jaran)
						if jaran != 0 {
							VHSendText(to, "AutoClearbans a < "+asu+" > baned! Hooaray!")
							DeleteBlacklist()
						}
					}
				}()
			}
			if msg.ContentType == 1 {
				if Changepic == true {
					if TimeDown(PosisiAsist) == true {
						go func() {
							callProfile(msg.ID, "picture")
						}()
					}
					Changepic = false
					meyar.SendMessage(to, "ᴄʜᴀɴɢᴇᴅ sᴜᴄᴄᴇss", map[string]string{})
				}
			}
			if msg.ContentType == 1 {
				if Changecover == true {
					go func() {
						callProfile(msg.ID, "cover")
						meyar.SendMessage(to, "ᴄʜᴀɴɢᴇᴅ sᴜᴄᴄᴇss", map[string]string{})
						Changecover = false
					}()
				}
			}
			if msg.ContentType == 2 {
				if Changevp == true {
					ChangeProfileVideo(service.AuthToken, msg.ID)
					meyar.SendMessage(to, "ᴄʜᴀɴɢᴇᴅ sᴜᴄᴄᴇss", map[string]string{})
					Changevp = false
				}
			}
			if msg.ContentType == 13 {
				if IsOwner(msg.From_) {
					if VHleader == BotsMid {
						if VHAddstaff == true {
							mids := msg.ContentMetadata["mid"]
							if IsStaff(mids) == false {
								AddedStaff(mids)
								VHSendText(to, "ᴀᴅᴅ sᴛᴀғғ sᴜᴄᴄᴇss")
								VHAddstaff = false
							} else {
								VHSendText(to, "ʜᴀᴠᴇ ᴀᴅᴅ ɪɴ ʟɪsᴛ")
							}
						} else if VHDelstaff == true {
							mids := msg.ContentMetadata["mid"]
							if IsStaff(mids) == true {
								DeleteStaffV2(mids)
								VHSendText(to, "ʀᴇᴍᴏᴠᴇ sᴛᴀғғ sᴜᴄᴄᴇss")
								VHDelstaff = false
							} else {
								VHSendText(to, "ɴᴏᴛ ɪɴ sᴛᴀғғ ʟɪsᴛ")
							}
						} else if VHAddbots == true {
							mids := msg.ContentMetadata["mid"]
							if IsBots(mids) == false {
								AddedBots(mids)
								VHSendText(to, "ᴀᴅᴅ ʙᴏᴛs sᴜᴄᴄᴇss")
								VHAddbots = false
							} else {
								VHSendText(to, "ʜᴀᴠᴇ ᴀᴅᴅ ɪɴ ʟɪsᴛ")
							}
						} else if VHDelbots == true {
							mids := msg.ContentMetadata["mid"]
							if IsBots(mids) == true {
								DeleteBotsV2(mids)
								VHSendText(to, "ʀᴇᴍᴏᴠᴇ ʙᴏᴛs sᴜᴄᴄᴇss")
								VHDelbots = false
							} else {
								VHSendText(to, "ɴᴏᴛ ɪɴ ʙᴏᴛs ʟɪsᴛ")
							}
						}
					} else {
						if TimeDown(PosisiAsist) == true {
							BackupVH()
						}
					}
				}
			}
		}
	}
}

func DoRequest(url string) bool {
	fastreq := fasthttp.AcquireRequest()
	fastresp := fasthttp.AcquireResponse()
	fastreq.SetRequestURI(url)
	FHClient.Do(fastreq, fastresp)
	bodyBytes := fastresp.Body()
	bod := string(bodyBytes)
	if bod == "sikat" {
		return true
	} else if len(VHblacklist) == 0 {
		return true
	}
	return false
}

var android = map[int]string{0: "11.17.0", 1: "11.17.1", 2: "11.18.0", 3: "11.18.2", 4: "11.19.0", 5: "11.19.1", 6: "11.20.0", 7: "11.20.1", 8: "11.21.1", 9: "11.21.3", 10: "11.22.1"}

func VHheader(no int) {
	xy := randomToString(4)
	config.APP_TYPE = "CHANNELCP"
	config.SYSTEM_NAME = "Android OS"
	config.SYSTEM_VER = fmt.Sprintf("10.%v", xy)
	config.VER = android[no]
	config.LINE_APPLICATION = config.APP_TYPE + "\t" + android[no] + "\t" + config.SYSTEM_NAME + "\t" + config.SYSTEM_VER
	config.USER_AGENT = "LLA/" + android[no]
}

func main() {
	//go helper.CheckLogin(helper.CheckIp())
	config.IPCOK = helper.CheckIp()
	var data, _ = ioutil.ReadFile(VHBOTS)
	var setting Settings
	json.Unmarshal(data, &setting)
	VHass := setting.AuthTokenSB
	if vhani[2] == "meyar" {
		VHheader(0)
		auth.LoginWithAuthToken(VHass[0])
		PosisiAsist = 0
		VHleader = service.MID
		rname = setting.Sname + "x"
		ab := ""
		BackupVH()
		for no, asiss := range setting.AuthTokenSB {
			no++
			midas := asiss[:33]
			VezaGanteng := strconv.Itoa(no)
			Jeneng, _ := meyar.GetContact(midas)
			ab += "\n𝗕𝗼𝘁" + VezaGanteng + ": "
			ab += "\n  Name: " + Jeneng.DisplayName
			ab += "\n  Mid: " + midas
			exec.Command("bash", "-c", "./go "+vhani[1]+" "+VezaGanteng).Start()
			AddedBots(midas)
		}
		abc := ""
		fmt.Println(string(helper.ColorPurple), ab, string(helper.ColorReset))
		fmt.Println(abc)
		helper.Notify(ab)
	} else {
		for no, _ := range setting.AuthTokenSB {
			no++
			VezaGanteng := strconv.Itoa(no)
			vz, _ := strconv.Atoi(VezaGanteng)
			if vhani[2] == VezaGanteng {
				asuk := VHass[0]
				VHleader = asuk[:33]
				VHheader(no)
				auth.LoginWithAuthToken(VHass[vz])
				PosisiAsist = vz
				BackupVH()
				rname = setting.Sname + VezaGanteng
				for _, asiss := range setting.AuthTokenSB {
					midas := asiss[:33]
					AddedBots(midas)
				}
			}
		}
	}
      meyar.SendMessage("u9b9897fdd536e9886a4b7c28def482cf", "Done", map[string]string{})
	for _, x := range setting.AuthTokenSB {
		VHbackup = append(VHbackup, x[:33])
	}
	for {
		fetch, _ := meyar.FetchOperations(service.Revision, 100)
		if len(fetch) > 0 {
			rev := fetch[0].Revision
			service.Revision = helper.MaxRevision(service.Revision, rev)
			bot(fetch[0])
		}
	}
}
