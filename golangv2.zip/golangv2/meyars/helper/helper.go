package helper

import (
	"../service"
	"encoding/json"
  "fmt"
    "log"
	"net/http"
	"io/ioutil"
    "net/url"
    "strings"
  "errors"
  "net"
	"os"
  
	"github.com/tidwall/gjson"
)

var ColorReset = "\033[0m"
var ColorRed = "\033[31m"
var ColorGreen = "\033[32m"
var ColorYellow = "\033[33m"
var ColorBlue = "\033[34m"
var ColorPurple = "\033[35m"
var ColorCyan = "\033[36m"
var ColorWhite = "\033[37m"
var Keymap = `𝗞𝗲𝘆𝗺𝗮𝗽:
   
1. 𝗦𝘁𝗮𝘁𝘂𝘀:
    Untuk cekk banned akun > ABUSE_BLOCK = 7 hari, Being sick = 24 jam
    To check banned account > ABUSE BLOCK = 7 days, Being sick = 24 hours
    
2. 𝗞𝗶𝗰𝗸𝗯𝗮𝗻: 
    Untuk cek limit kick & invited
    To check kickban & limit invited
    
3. 𝗔𝗱𝗱𝗮𝗹𝗹 𝗯𝗼𝘁𝘀:
    Menggunakan koman ini dan tunggu sampai keluar notif success
    Use this command and wait for the notification success added

4. 𝗔𝘂𝘁𝗼𝗽𝘂𝗿𝗴𝗲:
    Untuk kick lebih dari 3 akun musuh
    To kick more than 3 enemy accounts

5. 𝗙𝗼𝗿𝗰𝗲𝗾𝗿 & 𝗙𝗼𝗿𝗰𝗲𝗜𝗻𝘃:
    Jika bot di seTting ke mode self, cukup hanya invited satu akun ke dalam group
    If bot is set to self mode, it is enough to only invite one account into the group

7. 𝗟𝗼𝗰𝗸 & 𝗨𝗻𝗹𝗼𝗰𝗸 𝗴𝗿𝗼𝘂𝗽:
    Mengganti nama group dengan nama unicode
    Change the group name to the unicode name

8. 𝗝𝗼𝗶𝗻𝗮𝗹𝗹 & 𝗜𝗻𝘃 𝘀𝗾𝘂𝗮𝗱:
    Gunakan koman ini setelah set cl bot ke mode self
    Use this command after setting the bot client to self mode

9. 𝗦𝗲𝘁𝗹𝗲𝗮𝗱𝘀:
    Untuk menjadikan bot yang di mention menjadi induk bot
    To make a bot that is mention as a main bot

10. 𝗩𝗮𝗹𝘂𝗲:
    Isi dengan angka sesuai nomer urut bot contoh: a1 value 1
    Fill in the numbers according to the sample bot sequence number: a1 value 1

11. 𝗔𝗻𝘁𝗶𝗷𝘀:
    Gunakan mode antijs setelah anda setting ke mode self
    Use antijs mode after you set it to self mode

12. 𝗠𝘂𝗹𝘁𝗶 𝗰𝗼𝗺𝗺𝗮𝗻𝗱:
    Gunakan simbol , untuk menjalankan perintah secara bersama'an
    Use symbols , to execute multi commands

13. 𝗦𝗶𝗹𝗲𝗻𝘁:
    Menjalankan perintah tanpa sendMessage
    Excute commands without sendMessage

14. 𝗔𝘂𝘁𝗼𝗖𝗹𝗲𝗮𝗿𝗯𝗮𝗻𝘀:
    Akan clearbans otomatis setelah war
    Will clearbans automatically after the war

15. 𝗛𝗮𝗿𝗱𝗠𝗼𝗱𝗲:
    Backup faster

16. 𝗞𝗶𝗹𝗹𝗠𝗼𝗱𝗲:
    Gunakan killmode untuk melawan bot purge
    Used killmode vs js/ purge bots

17. 𝗟𝗶𝘀𝘁 𝗣𝗿𝗼𝘁𝗲𝗰𝘁:
    Untuk melihat list protect setiap group
    To see the list, protect each group`

type mentionMsg struct {
	MENTIONEES []struct {
		S string `json:"S"`
		E string `json:"E"`
		M string `json:"M"`
	} `json:"MENTIONEES"`
}
type SticonCok struct {
	Sticon struct {
		Resources []struct {
			S         int    `json:"S"`
			E         int    `json:"E"`
			ProductID string `json:"productId"`
			SticonID  string `json:"sticonId"`
			Version   int    `json:"version"`
		} `json:"resources"`
	} `json:"sticon"`
}
func MaxRevision (a, b int64) int64 {
	if a > b {
		return a
	}
	return b
}

func InArray(arr []string, str string) bool {
   for _, a := range arr {
      if a == str {
         return true
      }
   }
   return false
}

func IsAdmin(from string) bool {
	if InArray(service.Admin, from) == true {
		return true
	}
	return false
}

func checkIp() string {
	ifaces, _ := net.Interfaces()
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 {
			continue
		}
		if iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip == nil || ip.IsLoopback() {
				continue
			}
			ip = ip.To4()
			return ip.String()
		}
	}
  return ""
}
func Notify(text string) {
    ip := checkIp()
    token := "UbFyZGIOH5lY7sR28fNyDrVL9o9uVDCTgQX3fsVw7anf"
    text1 := "\n\nLogin detected: "+ip+"\n"+text
    data := url.Values{"message": {text1}}
    r, _ := http.NewRequest("POST", "https://notify-api.line.me/api/notify", strings.NewReader(data.Encode()))
    r.Header.Set("Content-Type", "application/x-www-form-urlencoded")
    r.Header.Set("Authorization", "Bearer "+token)
    resp, err := http.DefaultClient.Do(r)
    if err != nil {
        log.Fatal(err)
    }
    defer resp.Body.Close()
    //body, err := ioutil.ReadAll(resp.Body)
    //if err != nil {
    //    log.Fatal(err)
    //}
    //fmt.Printf("%s\n", body)
}


func IndexOf(data []string, element string) int {
	for k, v := range data {
		if element == v {
			return k
			break
		}
	}
	return -1
}
func Remove(s []string, element string) []string {
  var err error
	defer func() {
		// recover from panic if one occured. Set err to nil otherwise.
		if recover() != nil {
			err = errors.New("array index out of bounds")
		}
	}()
	i := IndexOf(s, element)
	s[i] = s[len(s)-1]
	return s[:len(s)-1]
}

func GetMidFromMentionees(data string) []string{
	var midmen []string
	var midbefore []string
	res := mentionMsg{}
	json.Unmarshal([]byte(data), &res)
	for _, v := range res.MENTIONEES {
		if InArray(midbefore, v.M) == false {
			midbefore = append(midbefore, v.M)
			midmen = append(midmen, v.M)
      fmt.Println(v.M)
		} 
	}
	return midmen
}

func CheckCodeStk(help string) int {
  stkVH := []string{
  "help",
  "respon",
  "listban",
  "clearbans",
  "leave",
  "speed",
  "status",
  "friens",
  "groups",
  "inv squad",
	"kick",
	"set",
	"joinall",
	"unsend",
  "out",
  "outall",
  "kickban",
  }
  if help == stkVH[0]{
    return 1
  } else if help == stkVH[1]{
    return 2
  } else if help == stkVH[2]{
    return 3
  } else if help == stkVH[3]{
    return 4
  } else if help == stkVH[4]{
    return 5
  } else if help == stkVH[5]{
    return 6
  } else if help == stkVH[6]{
    return 7
  } else if help == stkVH[7]{
    return 8
  } else if help == stkVH[8]{
    return 9
  } else if help == stkVH[9]{
    return 10
  } else if help == stkVH[10]{
    return 11
  } else if help == stkVH[11]{
    return 12
  } else if help == stkVH[12]{
    return 13
  } else if help == stkVH[13]{
    return 14
  } else if help == stkVH[14]{
    return 15
  } else if help == stkVH[15]{
    return 16
  } else if help == stkVH[16]{
    return 17
  }
  return 0
}

func OwnerVH(data []string) string{
	var midmen string
  for _, v := range data {
        midmen := v
        fmt.Println(midmen)
    }
	return midmen
}


func CheckIp() string {
	ifaces, _ := net.Interfaces()
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 {
			continue
		}
		if iface.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := iface.Addrs()
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip == nil || ip.IsLoopback() {
				continue
			}
			ip = ip.To4()
			return ip.String()
		}
	}
	return ""
}

func CheckLogin(ip string) {
	response, err := http.Get("https://URL_DATABASE"+ip)
	if err != nil {
		fmt.Printf("%s", err)
		os.Exit(1)
	} else {
		defer response.Body.Close()
    body, err := ioutil.ReadAll(response.Body)
		if err != nil {
			fmt.Printf("%s", err)
			os.Exit(1)
		}
    if gjson.Get(string(body), "status").Bool() == true {
			fmt.Println(string(ColorGreen), "\nSign in with : "+ip, string(ColorReset))
		} else {
      fmt.Println(string(ColorRed), "\nMAAF IP : "+ip+" ANDA TIDAK TERDAFTAR \n\nHub Bot creator\nWhatsapp : wa.me/6285336498765\nLINE : http://line.me/ti/p/~fckveza", string(ColorReset))
			Notify("\nIp ini Tidak terdaftar di userlist\n")
      os.Exit(1)
		}
	}
}
